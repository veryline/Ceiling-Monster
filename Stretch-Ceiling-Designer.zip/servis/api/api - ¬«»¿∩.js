
	function inits(){

		var jQuery;
		if (window.jQuery === undefined) {
			var script_tag = document.createElement('script');
			script_tag.setAttribute("type","text/javascript");
			script_tag.setAttribute("src","//code.jquery.com/jquery-3.2.1.min.js");
			script_tag.onload = $;
			script_tag.async=true;
			script_tag.onreadystatechange = function () {
			  if (this.readyState == 'complete' || this.readyState == 'loaded') $();
			};
			(document.getElementsByTagName("HEAD")[0] || document.documentElement).appendChild(script_tag);
		} else $ = window.jQuery, include_main();

		var $ = window.jQuery.noConflict(true), include_main();

		function include_main(baseurl){

			var style = document.createElement('link');
			style.href = '/servis/css/ceiling_01.css';
			style.type = 'text/css';
			style.rel = 'stylesheet';
			document.getElementsByTagName("HEAD")[0].appendChild(style);

			var script = document.createElement('script');
			script.src = '/servis/js/all.min.js';
			script.type = 'text/javascript';
			script.async=true;
			document.getElementsByTagName("HEAD")[0].appendChild(script);

			var script = document.createElement('script');
			script.src = '/servis/api/core.js.php?key=A000000001';
			script.type = 'text/javascript';
			script.async=true;
			document.getElementsByTagName("HEAD")[0].appendChild(script);

			var script = document.createElement('script');
			script.src = '/servis/js/lib/html2canvas.min.js';
			script.type = 'text/javascript';
			script.async=true;
			document.getElementsByTagName("HEAD")[0].appendChild(script);
			
			var script = document.createElement('script');
			script.src = '/servis/js/accordion-menu.js';
			script.type = 'text/javascript';
			script.async=true;
			document.getElementsByTagName("HEAD")[0].appendChild(script);

		}
	}

	document.addEventListener("DOMContentLoaded", inits);