	function inits(){
		var element = jQuery, document.getElementsByTagName("HEAD")[0];
		if (window.jQuery === undefined) {
			var script_tag = document.createElement('script');
			script_tag.setAttribute("type","text/javascript");
			script_tag.setAttribute("src","http://code.jquery.com/jquery-3.2.1.min.js");
			script_tag.onload = scriptLoadHandler;
			script_tag.async=true;
			script_tag.onreadystatechange = function () {
			  if (this.readyState == 'complete' || this.readyState == 'loaded') scriptLoadHandler();
			};
			(element || document.documentElement).appendChild(script_tag);
		} else { 
		  $ = window.jQuery; 
			include_main();
			console.log('yes jquery');
		}

		function scriptLoadHandler() {
		  $ = window.jQuery.noConflict(true);
		  include_main();
		}

		function include_main(){
			var baseurl = ("https:" === document.location.protocol ? "https://" + location.host : "http://" + location.host);

			var style = document.createElement('link');
			style.href = baseurl + '/servis/css/ceiling_01.css';
			style.type = 'text/css';
			style.rel = 'stylesheet';
			element.appendChild(style);

			var script = document.createElement('script');
			script.src = baseurl + '/servis/js/all.min.js';
			script.type = 'text/javascript';
			script.async=true;
			element.appendChild(script);

			var script = document.createElement('script');
			script.src = baseurl + '/servis/api/core.js.php?key=A000000001';
			script.type = 'text/javascript';
			script.async=true;
			element.appendChild(script);

			var script = document.createElement('script');
			script.src = baseurl + '/servis/js/lib/html2canvas.min.js';
			script.type = 'text/javascript';
			script.async=true;
			element.appendChild(script);
			
			var script = document.createElement('script');
			script.src = baseurl + '/servis/js/accordion-menu.js';
			script.type = 'text/javascript';
			script.async=true;
			element.appendChild(script);

		}
	}

	document.addEventListener("DOMContentLoaded", inits);