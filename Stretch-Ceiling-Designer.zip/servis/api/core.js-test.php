<?php

	require_once('../config.php');

	[
	    { "command": "clear_location", "caption": "Очистить" },
	    { "command": "add_directory", "caption": "Добавить папку" },
	    { "command": "add_where_snippet", "args": {"snippet": "*.${0:txt}"}, "caption": "Фильтр файлов по маске" },
	    { "command": "add_where_snippet", "args": {"snippet": "-*.${0:txt}"}, "caption": "Исключить файлы по маске" },
	    { "command": "add_where_snippet", "args": {"snippet": "<open folders>"}, "caption": "Добавить открытые папки" },
	    { "command": "add_where_snippet", "args": {"snippet": "<open files>"}, "caption": "Добавить открытые файлы" },
	    { "command": "add_where_snippet", "args": {"snippet": "<current file>"}, "caption": "Добавить текущий файл" }
	]

	[
		{ "caption": "Новый файл", "command": "new_file_at", "args": {"dirs": []} },
		{ "caption": "Переименовать…", "command": "rename_path", "args": {"paths": []} },
		{ "caption": "Удалить файл", "command": "delete_file", "args": {"files": []} },
		{ "caption": "Открыть папку файла…", "command": "open_containing_folder", "args": {"files": []} },
		{ "caption": "-", "id": "folder_commands" },
		{ "caption": "Новая папка…", "command": "new_folder", "args": {"dirs": []} },
		{ "caption": "Удалить папку", "command": "delete_folder", "args": {"dirs": []} },
		{ "caption": "Найти в папке…", "command": "find_in_folder", "args": {"dirs": []} }
		{ "caption": "-", "id": "end" }
	]

?>