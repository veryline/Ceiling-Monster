<?php

require_once('../config.php');
$key = $_GET['key'];




if($_GET['key'] == $PASSWORD) {

	function removeHtmlComments($file) {
		$start_param = array(
			'canvas_popup_load',
			'canvas_popup_crop',
			'canvas_popup_border',
			'canvas_photo_view',
			'canvas_crop_view',
			'canvas_grad_view',
			'canvas_cail_view',
			'canvas_blur_view',
			'currentShape',
			'currentCircle',
			'baseurl',
			'mode',
			'point_mass',
			'blur_reserv',
			'containers_main',
			'containers_construct',
			'right_box_container_view',
			'paintcanvas',
			'receivedImage',
			'loadcrops',
			'left_box_container_view',
			'photo_confirm',
			'savecanvas',
			''
		);

		for($m = 0;$m <= count($start_param)-1; $m++){
			$end_param[$m]= '__'.md5(uniqid(rand(),true));
		}
		$file = str_replace($start_param,$end_param,$file);
		$file = str_replace(array("\r","\n","\t"),"",$file);
		return $file ;
	}
		ob_start('removeHtmlComments');
		
		
		//$pathToFile = $_SERVER['DOCUMENT_ROOT'] . '/string.html';
		//if (file_exists($pathToFile)) readfile($pathToFile);
		

		
	#header('Content-Type: application/x-javascript; charset=utf8');
	
?>
	 
		var baseurl = "<?=$baseurl;?>";
		var mode = "add";
		var point_mass; 
		var blur_reserv;
		var canvas_popup_load;
		var canvas_popup_crop;
		var canvas_popup_border;
		var canvas_photo_view;
		var canvas_crop_view;
		var canvas_grad_view; 
		var canvas_cail_view;
		var canvas_blur_view;
		var currentShape;
		var currentCircle;
		var offset_x = 0;
		var offset_y = 0;

		
		
		function SAVECANVAS() {
			$(".step_control").hide();
			html2canvas(screenshot, {
				onrendered: function(canvas) {
					var base64 = canvas.toDataURL("image/png");
					var messege = { screenshot: base64 };
					$.ajax({
						type: 'POST',
						url: baseurl+'save/screenshot.php',
						data: messege,
						cache: true,
						success: function(start) {
							var link = document.createElement('a');
							link.setAttribute('href', baseurl+'save/xxxxxxx.png');
							link.setAttribute('download','download');
							onload=link.click();
							$(".step_control").fadeIn();
							alert(start);
						}
					});
				}
			});
		}
		
		
		
		function PRTFOLIO() {
			$.getJSON(baseurl+'save/handler.php', function(data) {
				var prtfolio = '<ul id="gallery">';
				$.each(data, function(key, val) {
					prtfolio += '<li><img src="'+baseurl+'save/'+val+'" width="70" height="70" /></li>';
				});
				prtfolio += '</ul>';
				$('.prtfolio').html(prtfolio);
			});	
		};

		
		function sendform(){
			var squ = $("[name='squ']").val();
			var name = $("[name='name']").val();
			var phone = $("[name='phone']").val();
			
			$.ajax({
				url: baseurl+'api/mail.php',
				type: "POST",
				data: "squ="+squ+"&name="+name+"&phone="+phone,
				success: function(accesshost){
					alert(accesshost);
				}
			});
		}
		

		
	var API_URL = 'https://api.shutterstock.com/v2/';
	var clientId = '1c76e-8fef5-29cc6-1771e-1b4fe-07c7c';
	var clientSecret = 'fae05-aaa72-add2a-a45d2-bbe86-18458';

	
    function search(opts) {
        var $container = $('#image-search-results');
		createComponentFunc = renderImageComponent;
		
        authorization = 'Basic ' + window.btoa(clientId + ':' + clientSecret);

        var jqxhr = $.ajax({
			url: API_URL + 'images/search',
			data: opts,
			headers: {
				Authorization: authorization
			}
        }).done(function(data) {
			
			if (data.total_count === 0) {
				$container.append('<p>Нет результата</p>');
				return;
			}

			$.each(data.data, function(i, item) {
				var component = createComponentFunc(item);
				$container.append(component);
			});

			if (window.innerWidth < 600) $('.collapse.in').collapse();
        });

        return jqxhr;
    }

	  
	  
    function fetchDetails(event) {
        event.preventDefault();
        var id = event.target.id;
        var authorization = 'Basic ' + window.btoa(clientId + ':' + clientSecret);
		
		if (!id || !authorization) return;
        renderLoadingDetails(id);

        var jqxhr = $.ajax({
            url: API_URL + 'images/' + id,
            headers: {
              Authorization: authorization
            }
        
		}).done(function(data) {
            if (!data || !data.assets || !data.assets) return;
			renderDetails(data);
		});
		
        return jqxhr;
    };


    function renderImageComponent(image) {
        if (!image || !image.assets || !image.assets.large_thumb || !image.assets.large_thumb.url) return;
        var wrapper = $('<div>');
        var thumbWrapper = $('<div>');
        var thumbnail = $('<img>');
        $(thumbnail).click(fetchDetails).attr('id', image.id).attr('src', image.assets.large_thumb.url);
        $(thumbWrapper).addClass('thumbnail-crop').append(thumbnail);
        $(wrapper).addClass('image-float-wrapper image horizontal-image').append(thumbWrapper);
        return wrapper;
	};

    function renderDetails(data) {
	
		var thumbWrapper = $('<div>');
		var thumbnail = $('<img>');
		var detailTemplate = $('.detail-template');
		var modalHeader = $('.modal-header');
		
		detailTemplate.find('.modal-body').html('<div></div>');
		$(thumbnail).click(fetchDetails).attr('id', data.id).attr('src', data.assets.preview.url);
        $(thumbWrapper).addClass('thumbnail-crop').append(thumbnail);
		detailTemplate.find('.modal-body').find('div').append(thumbWrapper);

		/* $(".modal-header p:eq(0)").html(data.id);
		$(".modal-header p:eq(1)").html(data.assets.preview.url);
		$(".modal-header p:eq(2)").html(data.assets.small_thumb.url);
		$(".modal-header p:eq(3)").html(data.assets.large_thumb.url); */
		
		/* $(".modal-header").find("a")
			.attr('href', 'http://www.shutterstock.com/pic.mhtml?id=' + data.id)
			.attr('target', '_blank')
			.text('http://www.shutterstock.com/pic.mhtml?id=' + data.id); */

    };
	

    function renderLoadingDetails(id) {
        var detailTemplate = $('.detail-template');
        detailTemplate.find('.modal-body').html('<i class="fa fa-5x fa-spinner fa-spin"></i>');
        detailTemplate.find('h3').html('Загрузка ' + id + '...');
        /* detailTemplate.modal('show'); */
    };
	
	
	
	
	
	
	
	
	
	function NUMBER_PLUS(){
		var $number = $('.number-list');
        $number.val(parseInt($number.val()) + 1).change();
		FOTOPECHAT($number.val());
        return false;
    }
	
	function NUMBER_MINUS(){
		var $number = $('.number-list');
        var count = parseInt($number.val()) - 1;
        count = count < 1 ? 1 : count;
        $number.val(count).change();
		FOTOPECHAT($number.val());
        return false;
    }
	
	function FOTOPECHAT(page) {
		$('#image-search-results').empty();
		var opts = $('#search-form input').serialize();
		opts += '&safe=true&orientation=horizontal';
		opts += '&page=' + page + '&per_page=12';
		search(opts);
		return false;
	};
	
	/* $("#image-search-results").find("img").on('click', function(){
		var id = $(this).attr("id");
		alert(id);
	}); */

	
	
	

	$(window).ready(function(){

		var containers_main = '' +
		'<img id="masks_box" src="<?=$baseurl;?>interfaces/preloader_01/image/black-twill.png" style="display:none;" />'+
		'<div class="box-bufer"><input id="new_file" type="file" name="file"></div>'+
		'<div class="box-loader"></div>'+
		'<div class="box-container"></div>';

		var containers_construct = '' +
		'<div class="main_construct">'+
			'<div class="up-panel-box">'+
				'<div class="box-accordion-menu"></div>'+
				'<div class="up_panel"></div>'+
				'<div id="box_search_form"></div>'+
				'<div id="box_fotobank_result"></div>'+
				'<div id="pagination_list"></div>'+
				'<div class="box_color_container"></div>'+
			'</div>'+
			'<div class="left_box_container"></div>'+
		'</div>'+
		'<div class="popup_construct">'+
		  '<div class="popup_mask"></div>'+
		  '<div class="popup_panel">'+
			'<div class="popup_view">'+
			  '<div class="panel_canvas">'+
				'<div class="panel_canvas_load prev1">'+
				  '<canvas id="canvas_popup_load" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>'+
				'</div>'+
				'<div class="panel_canvas_load prev2">'+
				  '<canvas id="canvas_popup_border" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>'+
				'</div>'+
				'<div class="panel_canvas_load prev3">'+
				  '<canvas id="canvas_popup_crop" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>'+
				'</div>'+
				'<div class="panel_load_message">'+
					'<div class="panel_load_mask"></div>'+
					'<div class="panel_load_button">'+
						'<div class="panel_button_confirm">'+
							'<p><?=$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS;?></p>'+
							'<button class="confirm_crop"><?=$ALL_CLEAR;?></button>'+
						'</div>'+
					'</div>'+
				'</div>'+
				'<div class="panel_load_step">'+
					'<div class="panel_load_mask"></div>'+
					'<div class="panel_load_step_view">'+
						'<p class="bolds"><?=$ATTENTION;?></p>'+
						'<p><?=$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA;?></p>'+
						'<p><?=$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH;?></p>'+
						'<p><?=$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE;?></p>'+
					'</div>'+
				'</div>'+
				'<div class="panel_load_end">'+
					'<div class="panel_load_mask"></div>'+
					'<div class="panel_load_step_end">'+
						'<button class="confirm_crop_end"><?=$APPLY;?></button>'+
					'</div>'+
				'</div>'+
			  '</div>'+
			'</div>'+
			'<div class="popup_add">'+
			  '<button class="add_polygon"></button>'+
			  '<button class="del_polygon"></button>'+
			'</div>'+
		  '</div>'+
		'</div>'+
		'<div class="send_form_construct">'+
		  '<div class="popup_mask"></div>'+
		  '<div class="form_construct">'+
			'<div class="form_construct_user">'+
			  '<div class="fc_title"><?=$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING;?><br/><span><?=$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION;?></span></div>'+
			  '<div class="fc_input"><input  type="text" name="squ" class="fc_inp_cail" value="squcelling" placeholder="<?=$ENTER_THE_CEILING_AREA;?>" /></div>'+
				'<div class="fc_input"><input type="text" name="name" class="fc_inp_name" value="squcelling" placeholder="<?=$ENTER_YOUR_NAME;?>" /></div>'+
			  '<div class="fc_input_end"><input type="text" name="phone"class="fc_inp_tele" value="squcelling" placeholder="<?=$ENTER_TELEPHONE_NUMBER;?>" /></div>'+
			  '<div class="fc_button"><button class="fc_inp_send" onclick="sendform()" ><?=$GETTING_CALCULATING_IN_SMS;?></button><br/><span><?=$PRIVACY_POLICY;?></span></div>'+
			'</div>'+  
			'<div class="form_construct_file">'+
			 '<div class="fc_file"><button class="fc_but_file" onclick="SAVECANVAS();"><?=$SAVE_THE_IMAGE;?></button></div>'+
			'</div>'+
		  '</div>'+
		'</div>'+
		'<div class="detail-template modal">'+
			'<div class="modal-dialog">'+
				'<div class="modal-content">'+
					'<div class="modal-header">'+
						'<button type="button" class="close" data-dismiss="modal">x</button>'+
						'<p></p><br>'+
						'<p></p><br>'+
						'<p></p><br>'+
						'<p></p><br>'+
						'<a></a>'+
					'</div>'+
					'<div class="modal-body"></div>'+
					'<div class="modal-footer">'+
						'<button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>'+
					'</div>'+
				'</div>'+
			'</div>'+
		'</div>';
	
		var box_color_container = ''+
		'<div class="contorl_panel_view">'+
			'<div class="control_panel_color">'+
				'<div class="control_color_tab">'+
					'<span class="cont_color_tab1 select_color_tab"><?=$GLOSSY;?></span>'+
					'<span class="cont_color_tab2 dec_color_tab"><?=$MATTED;?></span>'+
					'<span class="cont_color_tab3 dec_color_tab"><?=$SATINE;?></span>'+
				'</div>'+
				'<div class="control_color_select"></div>'+
				'<div class="construktor_menu">'+
				'<nav>'+
					'<li class="construktor_hover"><a class="open_window11 bordertop"><img class="konstruktor_iconi" src="<?=$baseurl;?>img/konstruktor_menu_icon/konstruktor_menu_icon_lus.png" width="27"> <?=$CHANDELIER;?></a></li>'+
				'</nav>'+
				'</div>'+
				'<div class="control_color_info"></div>'+
			'</div>'+
		'</div>';
	
		var box_search_form = ''+
		'<form id="search-form">'+
			'<div class="form-group form-group-sm">'+
				'<input class="number-list" type="hidden" value="1"/>'+
				'<input name="query" placeholder="Поисковый запрос" class="form-control"/>'+
			'</div>'+
			'<button onclick="FOTOPECHAT(1)" id="submit" name="submit" type="button" class="search-button btn-primary"><i class="icon-btn-primary fa fa-search"></i> Поиск</button>'+
		'</form>';

		var box_result_fotobank = ''+
		'<div class="box-result-fotobank">'+
			'<button class="button-number-minus" onclick="NUMBER_MINUS()">--</button>'+
			'<div class="image-results">'+
				'<div id="image-search-results"></div>'+
			'</div>'+
			'<button class="button-number-plus" onclick="NUMBER_PLUS()">++</button>'+
		'</div>';

		var pagination = ''+
		'<ul class="pagination pagination-sm">'+
			'<li><a href="#">«</a></li>'+
			'<li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">2 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">3 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">4 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">5 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">6 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">7 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">8 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">9 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">10 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">11 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">12 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">13 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">14 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">15 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">16 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">17 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">18 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">19 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">20 <span class="sr-only">(current)</span></a></li>'+
			'<li><a href="#">»</a></li>'+
		'</ul>';
		

		$('.veryline').html(containers_main);
			
		$(document).on("click", ".construct_start", function(){
			$('.box-loader').fadeIn();
			$('.box-container').fadeOut();
			$('.popup_construct').fadeIn();
			
				canvas_popup_crop.clear();
				mode ="add";
				
				$('.panel_load_end').fadeOut();
				$('.prev1').html('<canvas id="canvas_popup_load" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
				$('.prev2').html('<canvas id="canvas_popup_border" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
				$('.prev3').html('<canvas id="canvas_popup_crop" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');

				$('.load_panel').fadeIn();
				$('.panel_canvas').fadeOut();
			});
			
			/* PRTFOLIO(); */

		$('.box-loader').load(baseurl+'template/<?=$TEMPLATE; ?>/index.php', function() {

				$('.box-container').html(containers_construct);
				$("#submit").click();

				$('#box_search_form').html(box_search_form);
				$('#box_fotobank_result').html(box_result_fotobank);
				$('#pagination_list').html(pagination);
				$('.box_color_container').html(box_color_container);

			$('.control_color_select').load(baseurl+'interfaces/palitra/<?=$PALITRA; ?>/index.html', function() {

				$('.box-loader').fadeIn();
				var col_color = $('.control_color_select span').length;
				
				for (var ic = 0; ic <= col_color-1; ic++) {
					var color_new = $('.control_color_select span:eq('+ic+')').attr('class').split('_');
					$('.control_color_select span:eq('+ic+')').css({'background-color':'#'+color_new[1]});
				};

				$('.cont_color_tab1').click(function(){
					$('.cont_color_tab1').addClass('select_color_tab').removeClass('dec_color_tab');
					$('.cont_color_tab2').removeClass('select_color_tab').addClass('dec_color_tab');
					$('.cont_color_tab3').removeClass('select_color_tab').addClass('dec_color_tab');

					$('.pollo').css({'display':'none'});
					$('#lacquered').css({'display':'block'});
				});

				$('.cont_color_tab2').click(function(){
					$('.cont_color_tab1').removeClass('select_color_tab').addClass('dec_color_tab');
					$('.cont_color_tab2').addClass('select_color_tab').removeClass('dec_color_tab');
					$('.cont_color_tab3').removeClass('select_color_tab').addClass('dec_color_tab');

					$('.pollo').css({'display':'none'});
					$('#mat').css({'display':'block'});
				});

				$('.cont_color_tab3').click(function(){
					$('.cont_color_tab1').removeClass('select_color_tab').addClass('dec_color_tab');
					$('.cont_color_tab2').removeClass('select_color_tab').addClass('dec_color_tab');
					$('.cont_color_tab3').addClass('select_color_tab').removeClass('dec_color_tab');
					
					$('.pollo').css({'display':'none'});
					$('#sateen').css({'display':'block'});
				});

				$('.pollo span').click(function(){
				$('.cail_hide').css({'display':'none'});
					$('.pollo span').css({'background-image':'none','background-position':'center', 'background-repeat': 'no-repeat'});
					$(this).css({'background-image':'url(<?=$baseurl;?>interfaces/preloader_01/image/arrow-pattern.png)','background-position':'center', 'background-repeat': 'no-repeat'});
					
					var pattern_color = $(this).attr('class');
					var pattern_type = $(this).parent().attr('id');

					if(pattern_type=='lacquered') {
						var color_steck = pattern_color.split('_');
						var text_pattern = $(this).attr('id').split('_');
						var text_color = '<?=$GLOSSY;?> ('+text_pattern[0]+' '+text_pattern[1]+') <button style="background-color:#'+color_steck[1]+'" class="steck_color"></button>';
						$('.control_color_info').html('<?=$YOUR_CHOICE;?>: '+text_color);
					}
					
					if(pattern_type=='mat') {
						var color_steck = pattern_color.split('_');
						var text_pattern = $(this).attr('id').split('_');
						var text_color = '<?=$MATTED;?>('+text_pattern[0]+' '+text_pattern[1]+') <button style="background-color:#'+color_steck[1]+'" class="steck_color"></button>';
						$('.control_color_info').html('<?=$YOUR_CHOICE;?>: '+text_color);
					}
					
					if(pattern_type=='sateen') {
						var color_steck = pattern_color.split('_');
						var text_pattern = $(this).attr('id').split('_');
						var text_color = '<?=$SATINE;?> ('+text_pattern[0]+' '+text_pattern[1]+') <button style="background-color:#'+color_steck[1]+'" class="steck_color"></button>';
						$('.control_color_info').html('<?=$YOUR_CHOICE;?>: '+text_color);
					}
					paintcanvas(pattern_color, pattern_type);
				});

				$('.up_panel').load(baseurl+'interfaces/gallery_01.php', function() {
				var max_slide = 17;
	
				$('.gallery-next').click(function(){
				 var size_gallery = (parseInt($('.galler_slide_view ul').css('width')) - parseInt($('.galler_slide_view').css('width')));
				  var posit_x = parseInt($('.galler_slide_view ul').css('margin-left'));
				  if(posit_x >= (-(size_gallery-(70*2)))){
					$('.galler_slide_view ul').animate({'margin-left': (posit_x - 535)+"px"}, 200);
				  } else {
					$('.gallery-next').css({'display':'none'});
					$('.gallery-prev').css({'display':'block'});
				  }
				  
				});

				$('.gallery-prev').click(function(){
				  var size_gallery = (parseInt($('.galler_slide_view ul').css('width')) - parseInt($('.galler_slide_view').css('width')));
				  var posit_x = parseInt($('.galler_slide_view ul').css('margin-left'));
				 
				 if(posit_x <= -70){
					$('.galler_slide_view ul').animate({'margin-left': (posit_x + 535)+"px"}, 200);
				  } else {
					$('.gallery-next').css({'display':'block'});
					$('.gallery-prev').css({'display':'none'});
				  }
				  
				});

				$('.galler_slide_view ul li').click(function(){
					  $('.galler_slide_view ul li').removeClass("active");
					  $(this).addClass("active");

					  $('.cail_hide').css({'display':'block'});
					  $('.control_color_info').html('<?=$YOUR_CHOICE_PHOTO_PRINT;?> '+$(this).attr('data-index'));
					  
					  var crop = canvas_popup_crop.item(0);
					  var new_e = JSON.stringify(crop);
					  var jse = JSON.parse(new_e); 
					  var old_cail = canvas_cail_view.item(0);
					  canvas_cail_view.remove(old_cail);

					  var can2 = document.getElementById('canvas_cail_hide');
					  var img = new Image();
					  img.crossOrigin = "anonymous";
					  img.onload = function () {
						var ctx_cail = can2.getContext('2d');
						ctx_cail.save();
						ctx_cail.beginPath();
						ctx_cail.moveTo((parseInt(jse.points[0].x)+jse.left),jse.points[0].y+jse.top);
						for (var ip = 1; ip <=jse.points.length-1; ip++) {
						   ctx_cail.lineTo((parseInt(jse.points[ip].x)+jse.left),jse.points[ip].y+jse.top);
						};
						ctx_cail.closePath();
						ctx_cail.clip();
						ctx_cail.drawImage(img, 0, 0, <?=$CANVASWIDTH;?>, canvas_grad_view.item(0).height);
						ctx_cail.restore();
					  };
					  img.src = $(this).attr('data-image');


					  var p = new fabric.Polygon(jse.points, {
						  left: jse.left,
						  top: jse.top,
						  fill: 'green',
						  opacity:0,
						  perPixelTargetFind: true,
						  originX: 'something',
						  originY: 'something', 
						  selectable:false
					  });
					  canvas_cail_view.add(p);
					  var canvas_grad_xz = document.getElementById("canvas_cail_view"),
					  canvas_grad_ctx = canvas_grad_xz.getContext("2d");
					  canvas_grad_ctx.clip();

					  var grad = canvas_grad_ctx.createLinearGradient(0, 0, 0, canvas_grad_view.item(0).height);
					  grad.addColorStop(1, 'rgba(0, 0, 0, 0.5)');
					  grad.addColorStop(0.7, 'rgba(0, 0, 0, 0.3)');
					  grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
					  canvas_grad_ctx.fillStyle = grad;
					  canvas_grad_ctx.fillRect(0, 0, <?=$CANVASWIDTH;?>, canvas_grad_view.item(0).height);
				});


				
				$('#new_image').on('change', function(){

				  var input = document.getElementById('new_image');
				  if (!input) {
					alert("<?=$NO_DOWNLOAD_ITEM;?>");
				  } else if (!input.files) {
					alert("<?=$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS;?>");
				  } else if (!input.files[0]) {
					alert("<?=$NO_FILE_SELECTED_FOR_UPLOAD;?>");
				  } else {
				
					if ( errorMsg = validateFile(input.files[0]) ) {
						alert(errorMsg);
						return;
					} else {
					  $('.control_color_info').html('<?=$YOUR_CHOICE_YOUR_PHOTO_PRINTING;?>');

					file = input.files[0];
					fry = new FileReader();
					fry.onload = function(){

					  $('.cail_hide').css({'display':'block'});

					  var crop = canvas_popup_crop.item(0);
					  var new_e = JSON.stringify(crop);
					  var jse = JSON.parse(new_e); 
					  var old_cail = canvas_cail_view.item(0);
					  canvas_cail_view.remove(old_cail);
					  var can2 = document.getElementById('canvas_cail_hide');

					  var img = new Image();
					  img.crossOrigin = "anonymous";
					  img.onload = function () {
						var ctx_cail = can2.getContext('2d');
							ctx_cail.save();
							ctx_cail.beginPath();
							ctx_cail.moveTo((parseInt(jse.points[0].x)+jse.left),jse.points[0].y+jse.top);
							for (var ip = 1; ip <=jse.points.length-1; ip++) {
							   ctx_cail.lineTo((parseInt(jse.points[ip].x)+jse.left),jse.points[ip].y+jse.top);
							};
							ctx_cail.closePath();
							ctx_cail.clip();
							ctx_cail.drawImage(img, 0, 0, <?=$CANVASWIDTH;?>, canvas_grad_view.item(0).height);
							ctx_cail.restore();
					  };
					  img.src = fry.result;
						var gallery_w = parseInt($(".galler_slide_view ul").width());
						var gallery_col = parseInt($(".galler_slide_view ul li").length);
						$('.galler_slide_view ul li').css({'border':'2px solid #efeeee'});
						$(".galler_slide_view ul").prepend('<li onclick="newimage(this);" data-index="S'+gallery_col+'" data-image="'+fry.result+'" style="background-image: url('+fry.result+'); border: 2px solid red; "></li>').css({'width':(gallery_w+42)+'px'});
	  
					  var p = new fabric.Polygon(jse.points, {
						  left: jse.left,
						  top: jse.top,
						  fill: 'green',
						  opacity:0,
						  perPixelTargetFind: true,
						  originX: 'something',
						  originY: 'something', 
						  selectable:false
					  });
					  canvas_cail_view.add(p);

					  var canvas_grad_xz = document.getElementById("canvas_cail_view"),
					  canvas_grad_ctx = canvas_grad_xz.getContext("2d");
					  canvas_grad_ctx.clip();

					  var grad = canvas_grad_ctx.createLinearGradient(0, 0, 0, canvas_grad_view.item(0).height);
					  grad.addColorStop(1, 'rgba(0, 0, 0, 0.5)');
					  grad.addColorStop(0.7, 'rgba(0, 0, 0, 0.3)');
					  grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
					  canvas_grad_ctx.fillStyle = grad;
					  canvas_grad_ctx.fillRect(0, 0, <?=$CANVASWIDTH;?>, canvas_grad_view.item(0).height);
					};
		   
					fry.readAsDataURL(file);
				}
			}

		});

	});

});
			


					$('#new_file').on('change', function() {

						$('.box-loader').css({'display':'none'});
						$('.box-container').css({'display':'block'});
						$('.panel_load_message').css({'display':'block'});

						$('.prev1').html('<canvas id="canvas_popup_load" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
						$('.prev2').html('<canvas id="canvas_popup_border" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
						$('.prev3').html('<canvas id="canvas_popup_crop" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
				  
						
						var input = document.getElementById('new_file');
						
						if (!input) {
							console.log("<?=$NO_DOWNLOAD_ITEM;?>");
						
						} else if (!input.files) {
							console.log("<?=$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS;?>");
						
						} else if (!input.files[0]) {
							console.log("<?=$NO_FILE_SELECTED_FOR_UPLOAD;?>");
							$('.panel_button_confirm').css({'display':'none'});
							$('.confirm_ends').addClass('not_file_select');
						
						} else {
							if ( errorMsg = validateFile(input.files[0]) ) {
								alert(errorMsg);
								return;
							} else {
								$('.panel_button_confirm').css({'display':'block'});
								$('.confirm_ends').removeClass('not_file_select');
								
								file = input.files[0];
								fry = new FileReader();
								fry.onload = receivedImage;
								fry.readAsDataURL(file);
							}
						}
					});
				});
			});

			function validateFile(file) {
				if ( !file.type.match(/image\/(<?=$UPLOAD_TYPE;?>)/) ) {
					return '<?=$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT;?>';
				}
				var maxFileSize = <?=$FILESIZE;?> * 1024 * 1024;
				if ( file.size > maxFileSize ) {
					return '<?=$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED;?> <?=$FILESIZE;?>MB';
				}
			}


				function newimage(im) {
					$('.galler_slide_view ul li').css({'border':'2px solid #efeeee'});
					  $(im).css({'border':'2px solid red'});
					  $('.cail_hide').css({'display':'block'});
					  $('.control_color_info').html('<?=$YOUR_CHOICE_PHOTO_PRINT;?> '+$(im).attr('data-index'));
					  
					  var crop = canvas_popup_crop.item(0);
					  var new_e = JSON.stringify(crop);
					  var jse = JSON.parse(new_e); 
					  var old_cail = canvas_cail_view.item(0);
					  canvas_cail_view.remove(old_cail);
					  var can2 = document.getElementById('canvas_cail_hide');
					  
					  var img = new Image();
					  img.crossOrigin = "anonymous";
					  img.onload = function () {
						var ctx_cail = can2.getContext('2d');
						ctx_cail.save();
						ctx_cail.beginPath();
						ctx_cail.moveTo((parseInt(jse.points[0].x)+jse.left),jse.points[0].y+jse.top);
						for (var ip = 1; ip <= jse.points.length-1; ip++) {
						   ctx_cail.lineTo((parseInt(jse.points[ip].x)+jse.left),jse.points[ip].y+jse.top);
						};
						ctx_cail.closePath();
						ctx_cail.clip();
						ctx_cail.drawImage(img, 0, 0, <?=$CANVASWIDTH;?>, canvas_grad_view.item(0).height);
						ctx_cail.restore();
					  };
					  img.src = $(im).attr('data-image');


					  var p = new fabric.Polygon(jse.points, {
						  left: jse.left,
						  top: jse.top,
						  fill: 'green',
						  opacity:0,
						  perPixelTargetFind: true,
						  originX: 'something',
						  originY: 'something', 
						  selectable:false
					  });
					  canvas_cail_view.add(p);

					  var canvas_grad_xz = document.getElementById("canvas_cail_view"),
					  canvas_grad_ctx = canvas_grad_xz.getContext("2d");
					  canvas_grad_ctx.clip();

					  var grad = canvas_grad_ctx.createLinearGradient(0, 0, 0, canvas_grad_view.item(0).height);
					  grad.addColorStop(1, 'rgba(0, 0, 0, 0.5)');
					  grad.addColorStop(0.7, 'rgba(0, 0, 0, 0.3)');
					  grad.addColorStop(0, 'rgba(0, 0, 0, 0)');

					  canvas_grad_ctx.fillStyle = grad;
					  canvas_grad_ctx.fillRect(0, 0, <?=$CANVASWIDTH;?>, canvas_grad_view.item(0).height);
					};

				function receivedImage() {
					canvas_popup_load = this.__canvas = new fabric.Canvas('canvas_popup_load');
					canvas_popup_border = this.__canvas = new fabric.Canvas('canvas_popup_border');
					canvas_popup_crop = this.__canvas = new fabric.Canvas('canvas_popup_crop');
					
					var crossOriginImageObj = new Image();
					crossOriginImageObj.crossOrigin = "Anonymous";
					crossOriginImageObj.src = fry.result;
					crossOriginImageObj.onerror = function() { 
						console.log("cross-origin image load error"); 
					};
					crossOriginImageObj.onload = function() {
						var crossOriginImage = new fabric.Image( crossOriginImageObj, {});
						var formul_w = crossOriginImageObj.width / (crossOriginImageObj.height / <?=$CANVASHEIGHT;?>);
						var formul_h = crossOriginImageObj.height/ (crossOriginImageObj.width / <?=$CANVASWIDTH;?>);
						var margin_can = crossOriginImageObj.height - formul_h;

						if(formul_h < <?=$CANVASHEIGHT;?>) {
							var top_margin = <?=$CANVASHEIGHT;?> / 2;
						} else {
							var top_margin = formul_h / 2;
						}

						if(formul_w < <?=$CANVASWIDTH;?>) {
							var formul_wx = <?=$CANVASWIDTH;?>;
						} else {
							var formul_wx = formul_w;
						}

						crossOriginImage.set({left:(<?=$CANVASWIDTH;?>/2), top: top_margin , angle:0, selectable:false});
						crossOriginImage.scaleToWidth(formul_wx);
						canvas_popup_load.add(crossOriginImage);
				  
						$('.load_panel').fadeOut();
						$('.panel_canvas').fadeIn();

						var popup_border = document.getElementById("canvas_popup_border");
						var border_ctx = popup_border.getContext('2d'); 
						
						var img_setk = document.getElementById("masks_box");
						var pat = border_ctx.createPattern(img_setk,"repeat");
						
						border_ctx.beginPath();
						border_ctx.moveTo(0,0); 
						border_ctx.lineTo(<?=$CANVASWIDTH;?>,0); 
						border_ctx.lineTo(<?=$CANVASWIDTH;?>,<?=$CANVASHEIGHT;?>); 
						border_ctx.lineTo(0,<?=$CANVASHEIGHT;?>); 
						border_ctx.lineTo(0,0);
						
						border_ctx.lineTo(((<?=$CANVASWIDTH;?>-<?=$WIDTH;?>)/2),10);
						border_ctx.lineTo(((<?=$CANVASWIDTH;?>-<?=$WIDTH;?>)/2),<?=$HEIGHT;?>);
						border_ctx.lineTo(((<?=$CANVASWIDTH;?>-<?=$WIDTH;?>)/2)+<?=$WIDTH;?>,<?=$HEIGHT;?>);
						border_ctx.lineTo(((<?=$CANVASWIDTH;?>-<?=$WIDTH;?>)/2)+<?=$WIDTH;?>,10);
						border_ctx.lineTo(((<?=$CANVASWIDTH;?>-<?=$WIDTH;?>)/2),10);
					
						border_ctx.closePath();
						border_ctx.fillStyle=pat;
						border_ctx.fill();
						border_ctx.clip();
					    
						border_ctx.beginPath();
					    border_ctx.lineWidth="2";
					    border_ctx.strokeStyle="#ffffff";
					    border_ctx.setLineDash([4]);
					    border_ctx.rect(((<?=$CANVASWIDTH;?>-<?=$WIDTH;?>)/2),10,<?=$WIDTH;?>,<?=$HEIGHT;?>-10);
					    border_ctx.stroke();

						$('.confirm_crop').click(function(){
							$('.panel_load_message').fadeOut();
							$('.popup_add').fadeIn();
							$('.panel_load_step').fadeIn();
						});

						$('.confirm_ends').click(function() {
							$('.prev1').html('<canvas id="canvas_popup_load" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
							$('.prev2').html('<canvas id="canvas_popup_border" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
							$('.prev3').html('<canvas id="canvas_popup_crop" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
							
							$('.box-loader').fadeIn();
							$('.box-container').fadeOut();
							$('.load_panel').fadeOut();
							$('.panel_canvas').fadeOut();
						});
					   
						$('.add_polygon').click(function(){
							$('.panel_load_step').fadeOut();
							mode ="add";
							loadcrops();
						});

						$('.del_polygon').click(function(){
							canvas_popup_crop.clear();
							mode ="add";
							$('.panel_load_end').fadeOut();
						});
						
						$('.confirm_crop_end').click(function(){
							$('.popup_construct').fadeOut();
							EditorCanvas();
						});
	
					}
				};



				function loadcropsR(p){
					pos = [];
					pos.x = p[0];
					pos.y = p[1];
					
					if (mode==="add"){
						var polygon = new fabric.Line([pos.x-offset_x,pos.y-offset_y,(pos.x-offset_x)+1,(pos.y-offset_y)+1], { fill: 'red'});
						currentShape = polygon;
						canvas_popup_crop.add(currentShape);
						mode="edit";
						
					} else if (mode==="edit" && currentShape && currentShape.type==="line"){
						canvas_popup_crop.remove(currentShape);
						
						var points=[];
						points.push({x:currentShape.x1-(pos.x-offset_x),y:currentShape.y1-(pos.y-offset_y)});
						points.push({x:currentShape.x2-(pos.x-offset_x),y:currentShape.y2-(pos.y-offset_y)});
						points.push({x:currentShape.x2-(pos.x-offset_x)+5,y:currentShape.y2-(pos.y-offset_y)+5});
						
						var polygon = new fabric.Polygon(points, {
							fill: 'green', left: pos.x-offset_x, top: pos.y-offset_y, opacity:0.7, perPixelTargetFind: true,selectable:false
						});

						canvas_popup_crop.add(polygon);
						currentShape=polygon;
						canvas_popup_crop.renderAll();

					} else if ((mode==="edit") && currentShape && (currentShape.type === "polygon")){
						var points = currentShape.get("points");
						points.push({x:(pos.x-offset_x)-currentShape.get("left"),y:(pos.y-offset_y)-currentShape.get("top")});
						currentShape.set({points:points});
						canvas_popup_crop.renderAll();
					}

					function dblClickHandler (event) {
						mode ="add2";
						$('.panel_load_end').fadeIn();
						currentShape.setCoords();
					}
					
					fabric.util.removeListener(canvas_popup_crop.upperCanvasEl, 'dblclick', dblClickHandler);
				}
	
				function explode(delimiter, string) {
					var emptyArray = { 0: '' };
					if ( arguments.length != 2 || typeof arguments[0] == 'undefined' || typeof arguments[1] == 'undefined' ) return null;
					if ( delimiter === '' || delimiter === false || delimiter === null ) return false;
					if ( typeof delimiter == 'function' || typeof delimiter == 'object' || typeof string == 'function' || typeof string == 'object' ) return emptyArray;
					if ( delimiter === true ) delimiter = '1';
					return string.toString().split ( delimiter.toString() );
				}

				
				function loadcropsGallery(arg){
					array = arg;
					setTimeout(function(){
						array = explode(';', array);
						loadcropsR([array[0]]);
						array.forEach(function(coord) {
							loadcropsR(coord.split(','));
						});
						
						window.mode ="add2";
						$('.panel_load_end').fadeOut(200);
						
						window.currentShape.setCoords();
						$('.popup_construct').fadeOut(500);
						
						setTimeout(function(){
							EditorCanvas();
						}, 500);
					}, 300);
				}

				
				
				
				function loadcrops() {
					canvas_popup_crop.observe("mouse:move", function (event) {
						var pos = canvas_popup_crop.getPointer(event.memo.e);

						if (mode === "edit" && currentShape){
							if (currentShape.type==="line"){
								currentShape.set({x2:pos.x-offset_x,y2:pos.y-offset_y});
								canvas_popup_crop.renderAll();
							} else if (currentShape.type==="polygon"){
								var points = currentShape.get("points");
								points[points.length-1].x=(pos.x-offset_x)-currentShape.get("left");
								points[points.length-1].y=(pos.y-offset_y)-currentShape.get("top");
								currentShape.set({points:points});
								canvas_popup_crop.renderAll();
							}
							currentCircle.setLeft((pos.x-offset_x) - 1);
							currentCircle.setTop((pos.y-offset_y) - 1);
						}
					});

					canvas_popup_crop.observe("mouse:down", function (event) {
						var pos = canvas_popup_crop.getPointer(event.memo.e);

						if (mode === "add"){
							var polygon = new fabric.Line([pos.x-offset_x,pos.y-offset_y,(pos.x-offset_x)+1,(pos.y-offset_y)+1], { fill: 'red'});
							var circle = new fabric.Circle({ radius: 2, fill: 'red', scaleY: 1, left: pos.x-offset_x, top:pos.y-offset_y, selectable:false});
							
							currentShape = polygon;
							currentCircle = circle;
							canvas_popup_crop.add(currentShape);
							canvas_popup_crop.add(currentCircle);
							mode = "edit";
					
						} else if (mode==="edit" && currentShape && currentShape.type==="line"){
							canvas_popup_crop.remove(currentShape);
							var points = [];
							points.push({x:currentShape.x1-(pos.x-offset_x),y:currentShape.y1-(pos.y-offset_y)});
							points.push({x:currentShape.x2-(pos.x-offset_x),y:currentShape.y2-(pos.y-offset_y)});
							points.push({x:currentShape.x2-(pos.x-offset_x)+5,y:currentShape.y2-(pos.y-offset_y)+5});
							var polygon = new fabric.Polygon(points, {
								fill: 'green', left: pos.x-offset_x, top: pos.y-offset_y, opacity:0.7, perPixelTargetFind: true,selectable:false
							});
							canvas_popup_crop.add(polygon);
							currentShape = polygon;
							canvas_popup_crop.renderAll();

						} else if (mode==="edit" && currentShape && currentShape.type==="polygon"){
							var points = currentShape.get("points");
							points.push({x:(pos.x-offset_x)-currentShape.get("left"),y:(pos.y-offset_y)-currentShape.get("top")});
							currentShape.set({points:points});
							canvas_popup_crop.renderAll();
						}
					});

					function dblClickHandler(e){
						mode = "add2";
						$('.panel_load_end').css({'display':'block'});
						currentShape.setCoords();
						canvas_popup_crop.remove(currentCircle);
					}

					fabric.util.addListener(fabric.document, 'dblclick', dblClickHandler);
					fabric.util.removeListener(canvas_popup_crop.upperCanvasEl, 'dblclick', dblClickHandler);
				};


				function EditorCanvas(){
					
					var EDITWIDTH = "950";
					var EDITHEIGHT = "625";
					
					var CANVASWIDTH = "938";
					var CANVASHEIGHT = "615";
					
					var left_box_container_view = '' +
					'<div id="screenshot" class="box_conrainer_view">'+
						'<div class="canvas_conrainer_view">'+
							'<canvas id="canvas_photo_view" width="'+CANVASWIDTH+'" height="'+CANVASHEIGHT+'"></canvas>'+
						'</div>'+
						'<div class="canvas_conrainer_view crops">'+
							'<canvas id="canvas_crop_view" width="'+CANVASWIDTH+'" height="'+CANVASHEIGHT+'"></canvas>'+
						'</div>'+
						'<div class="canvas_conrainer_view blurs">'+
							'<canvas id="canvas_blur_view" width="'+CANVASWIDTH+'" height="'+CANVASHEIGHT+'"></canvas>'+
						'</div>'+
						'<div class="canvas_conrainer_view grads">'+
							'<canvas id="canvas_grad_view" width="'+CANVASWIDTH+'" height="'+CANVASHEIGHT+'"></canvas>'+
						'</div>'+
						'<div class="canvas_conrainer_view cail_hide">'+
							'<canvas id="canvas_cail_hide" width="'+CANVASWIDTH+'" height="'+CANVASHEIGHT+'"></canvas>'+
						'</div>'+
						'<div class="canvas_conrainer_view cails">'+
							'<canvas id="canvas_cail_view" width="'+CANVASWIDTH+'" height="'+CANVASHEIGHT+'"></canvas>'+
						'</div>'+
						'<div class="canvas_conrainer_view bord">'+
							'<canvas id="canvas_bord_view" width="'+CANVASWIDTH+'" height="'+CANVASHEIGHT+'"></canvas>'+
						'</div>'+
						'<p class="watter">Адрес: г.Ростов-наДону ул.Николая 2 оф 5, тел: +7(906)423-90-03</p>'+
						'<a id="logotip" href="http://ip.veryline.ru/" target="_blank"></a>'+
						'<div class="canvas_conrainer_view construct_end_edit">'+
							'<div class="step_control">'+
								'<button class="construct_start"><?=$BACK;?></button>'+
								'<button class="construct_screen" onclick="SAVECANVAS();"><?=$SAVE_THE_IMAGE;?></button>'+
								'<button class="construct_form">отправить</button>'+
							'</div>'+
						'</div>'+
						'<form><input name="screenshot" type="hidden" class="screen-uri"></form>'+
					'</div>';
					
					
		
					$('.left_box_container').html(left_box_container_view);
					$('#logotip').load(baseurl+'img/logotip.svg');
					
					$('.popup_mask').click(function(){
					  $('.send_form_construct').fadeOut();
					});

					$('.construct_form').click(function(){
					  $('.send_form_construct').fadeIn();
					});

					canvas_photo_view = this.__canvas = new fabric.Canvas('canvas_photo_view');
					canvas_crop_view = this.__canvas = new fabric.Canvas('canvas_crop_view');
					canvas_grad_view = this.__canvas = new fabric.Canvas('canvas_grad_view');
					canvas_cail_view = this.__canvas = new fabric.Canvas('canvas_cail_view');
					canvas_blur_view = this.__canvas = new fabric.Canvas('canvas_blur_view');

					var crop = canvas_popup_crop.item(0);
					var new_e = JSON.stringify(crop);
					var jse = JSON.parse(new_e);
					var c_p_v = document.getElementById("canvas_photo_view");
					var c_p_v_ctx = c_p_v.getContext('2d');
					
					/* Загружаем фоновое изображение*/
					var canvas_photo_img = new Image();
						canvas_photo_img.src = document.getElementById("canvas_popup_load").toDataURL();
						canvas_photo_img.onload = function() {
						c_p_v_ctx.drawImage(canvas_photo_img, 1-((EDITWIDTH-CANVASWIDTH)/2), 0);
					};
					
					/* Загружаем и переворачиваем картинку глянцевого отражения*/
					var canvas_crop_img = document.getElementById("canvas_popup_load").toDataURL();
					fabric.Image.fromURL(canvas_crop_img, function(img) {
						img.set({flipY:true,left:((CANVASWIDTH)/2), top:(CANVASHEIGHT/4), angle: 0});
						img.setCoords();
						canvas_crop_view.add(img);
					},{
						crossOrigin: 'Anonymous'
					});

					canvas_crop_view.clipTo = function(ctx) {
						crop.set({left:jse.left-((EDITWIDTH-CANVASWIDTH)/2), top:jse.top-2, angle: 0});
						crop.render(ctx);
						ctx.save();
					};
					  
					var p = new fabric.Polygon(jse.points, {
						left: jse.left-((EDITWIDTH-CANVASWIDTH)/2),
						top: jse.top-2,
						fill: 'green',
						opacity:0,
						perPixelTargetFind: true,
						originX: 'something',
						originY: 'something', 
						selectable:false
					});
					
					canvas_grad_view.add(p);
					var canvas_grad_xz = document.getElementById("canvas_grad_view"),
					canvas_grad_ctx = canvas_grad_xz.getContext("2d");
					canvas_grad_ctx.clip();

					var grad = canvas_grad_ctx.createLinearGradient(0, 0, 0, canvas_grad_view.item(0).height);
						grad.addColorStop(1, 'rgba(255, 255, 255, 1)');
						grad.addColorStop(0.5, 'rgba(255, 255, 255, 0.9)');
						grad.addColorStop(0, 'rgba(255, 255, 255, 0.7)');

					canvas_grad_ctx.fillStyle = grad;
					canvas_grad_ctx.fillRect(0, 0, CANVASWIDTH, canvas_grad_view.item(0).height);
					
					var bord = document.getElementById("canvas_bord_view");
					var bord_ctx = bord.getContext('2d');
						bord_ctx.beginPath();
						bord_ctx.lineWidth="2";
						bord_ctx.strokeStyle="#FFFFFF";
						bord_ctx.rect(0, 0, CANVASWIDTH, CANVASHEIGHT);
						bord_ctx.stroke();
				};

				function hexDec(h){
					var m=h.slice(1).match(/.{2}/g);
					var RGB = parseInt(m[0], 16) +',' +parseInt(m[1], 16) +','+ parseInt(m[2], 16);
					return RGB;
				};



	function paintcanvas(color_paint, type_paint) {
		var color_paint_fill = color_paint.split('_');
		$('.galler_slide_view ul li').removeClass("active");
		
		if(type_paint =='lacquered'){
			$('.crops').show();
			$('.blurs').hide;

			var crop = canvas_popup_crop.item(0);
			var new_e = JSON.stringify(crop);
			var jsr = JSON.parse(new_e);
			var old = canvas_grad_view.item(0);
			canvas_grad_view.remove(old);
			var ps = new fabric.Polygon(jsr.points, {
				left: jsr.left,
				top: jsr.top,
				fill:'#'+color_paint_fill[1],
				opacity:0.3,
				perPixelTargetFind: true,
				originX: 'something',
				originY: 'something', 
				selectable:false
			});
			canvas_grad_view.add(ps);

			var canvas_grad_xz = document.getElementById("canvas_grad_view"),
			canvas_grad_ctx = canvas_grad_xz.getContext("2d");
			canvas_grad_ctx.clip();

			var grad = canvas_grad_ctx.createLinearGradient(0, 0, 0, canvas_grad_view.item(0).height);
				grad.addColorStop(1, 'rgba('+hexDec('#'+color_paint_fill[1])+', 0.9)');
				grad.addColorStop(0.5, 'rgba('+hexDec('#'+color_paint_fill[1])+', 0.7)');
				grad.addColorStop(0, 'rgba('+hexDec('#'+color_paint_fill[1])+', 0.5)');

			canvas_grad_ctx.fillStyle = grad;
			canvas_grad_ctx.fillRect(0, 0, <?=$CANVASWIDTH;?>, canvas_grad_view.item(0).height);

		}
		
		
		if(type_paint == 'mat'){
			$('.crops').show();
			$('.blurs').hide();

			var crop = canvas_popup_crop.item(0);
			var new_e = JSON.stringify(crop);
			var jsr = JSON.parse(new_e);
			var old = canvas_grad_view.item(0);
			canvas_grad_view.remove(old);
			
			var ps = new fabric.Polygon(jsr.points, {
				left: jsr.left,
				top: jsr.top,
				fill:'#000000',
				opacity:1,
				perPixelTargetFind: true,
				originX: 'something',
				originY: 'something', 
				selectable:false
			});
			canvas_grad_view.add(ps);
			var canvas_grad_xz = document.getElementById("canvas_grad_view"),
			canvas_grad_ctx = canvas_grad_xz.getContext("2d");
			canvas_grad_ctx.clip();
			var grad = canvas_grad_ctx.createLinearGradient(0, 0, 0, canvas_grad_view.item(0).height);
			grad.addColorStop(1, 'rgba('+hexDec('#'+color_paint_fill[1])+', 0.7)');
			grad.addColorStop(0.5, 'rgba('+hexDec('#'+color_paint_fill[1])+', 0.9)');
			grad.addColorStop(0, 'rgba('+hexDec('#'+color_paint_fill[1])+', 1)');
			canvas_grad_ctx.fillStyle = grad;
			canvas_grad_ctx.fillRect(0, 0, <?=$CANVASWIDTH;?>, canvas_grad_view.item(0).height);
		}
		
		
		if(type_paint == 'sateen'){
			var crop = canvas_popup_crop.item(0);
			var new_e = JSON.stringify(crop);
			var jsr = JSON.parse(new_e);
			var old = canvas_grad_view.item(0);
			canvas_grad_view.remove(old);
			var ps = new fabric.Polygon(jsr.points, {
				left: jsr.left,
				top: jsr.top,
				height:jsr.height+5,
				fill:'#'+color_paint_fill[1],
				opacity:0,
				stroke: "#ccc",
				strokWidth: 2,
				perPixelTargetFind: true,
				originX: 'something',
				originY: 'something', 
					selectable:false
			});
			
			canvas_grad_view.add(ps);
			var canvas_grad_xz = document.getElementById("canvas_grad_view"),
			canvas_grad_ctx = canvas_grad_xz.getContext("2d");
			canvas_grad_ctx.clip();
			
			var grad = canvas_grad_ctx.createLinearGradient(0, 0, 0, canvas_grad_view.item(0).height);
				grad.addColorStop(1, 'rgba('+hexDec('#'+color_paint_fill[1])+', 0.9)');
				grad.addColorStop(0.5, 'rgba('+hexDec('#'+color_paint_fill[1])+', 0.8)');
				grad.addColorStop(0, 'rgba('+hexDec('#'+color_paint_fill[1])+', 0.7)');
			
			canvas_grad_ctx.fillStyle = grad;
			canvas_grad_ctx.fillRect(0, 0, <?=$CANVASWIDTH;?>, canvas_grad_view.item(0).height);

			$('.crops').hide();
			$('.blurs').show();

			
			var blur_reserv = document.getElementById("canvas_crop_view").toDataURL();
			var txtCanvas = document.getElementById('canvas_blur_view');
			var textOne = txtCanvas.getContext('2d');
			var alpha = 0.20;
			textOne.globalAlpha = alpha;
			
			var imga = new Image();
			imga.src = blur_reserv;
			imga.onload = function () {
				var position_x = new Array(0,2,-2,4,-4,6,-6,8,-8,10,-10);
				var step = 3;
				for (var io = 0; io <= 10; io++) {
					textOne.drawImage(imga, (position_x[io]), 0-(io*2.5)); 
				};
			}
		}
	};

	function startgallery(fileId, imgArray) {
		$('.box-loader').css({'display':'none'});
		$('.box-container').css({'display':'block'});
		$('.panel_load_message').css({'display':'none'});

		$('.prev1').html('<canvas id="canvas_popup_load" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
		$('.prev2').html('<canvas id="canvas_popup_border" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');
		$('.prev3').html('<canvas id="canvas_popup_crop" width="<?=$CANVASWIDTH;?>" height="<?=$CANVASHEIGHT;?>"></canvas>');

		$('.panel_button_confirm').css({'display':'none'});
		$('.confirm_ends').removeClass('not_file_select');

		var xhr = new XMLHttpRequest();
		xhr.open('GET', fileId, true);
		xhr.responseType = 'arraybuffer';
		xhr.onload = function(e) {
		  if (this.status == 200) {
		  array = this.response;
		  try{
			var png = new Blob( [array], {type : "image/png"});
		  }
		  catch(e){
			  window.BlobBuilder = window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder || window.MSBlobBuilder;
			  if(e.name == 'TypeError' && window.BlobBuilder){
				  var bb = new BlobBuilder();
				  bb.append(array.buffer);
				  var png = bb.getBlob("image/png");
			  } else if(e.name == "InvalidStateError"){
				  var png = new Blob( [array.buffer], {type : "image/png"});
			  }
		  }
			fry = new FileReader();
			fry.onload = receivedImage;
			fry.readAsDataURL(png);
			loadcropsGallery(imgArray);
		  }
		};
		xhr.send();
	}



	function startmain(){
		if ($('.box-loader').find('.panel_canvas')) {
			$('#new_file').click();
		}
	};
	

	<? ob_end_flush(); ?>

	
	
<!--// ЗАЩИТА ПО ДОМЕННОМУ ИМЕНИ -->
<?}else {
	?> <?=$ACCESSHOST;?> 
<?};?>