﻿
'<div class="close_lus" style="display:none;">x</div>'+
'<div class="gallery_lustra">'+
	'<div class="lus1_1"  style="display:none;"><img src="servis/interfaces/gallery_lus/1.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus2_2"  style="display:none;"><img src="servis/interfaces/gallery_lus/2.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus3_3"  style="display:none;"><img src="servis/interfaces/gallery_lus/3.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus4_4"  style="display:none;"><img src="servis/interfaces/gallery_lus/4.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus5_5"  style="display:none;"><img src="servis/interfaces/gallery_lus/5.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus6_6"  style="display:none;"><img src="servis/interfaces/gallery_lus/6.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus7_7"  style="display:none;"><img src="servis/interfaces/gallery_lus/7.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus8_8"  style="display:none;"><img src="servis/interfaces/gallery_lus/8.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus9_9"  style="display:none;"><img src="servis/interfaces/gallery_lus/9.png" alt=""  width="130" height="" class="drag" /></div>'+
	
	'<div class="lus10_10"  style="display:none;"><img src="servis/interfaces/gallery_lus/10.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus11_11"  style="display:none;"><img src="servis/interfaces/gallery_lus/11.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus12_12"  style="display:none;"><img src="servis/interfaces/gallery_lus/12.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus13_13"  style="display:none;"><img src="servis/interfaces/gallery_lus/13.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus14_14"  style="display:none;"><img src="servis/interfaces/gallery_lus/14.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus15_15"  style="display:none;"><img src="servis/interfaces/gallery_lus/15.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus16_16"  style="display:none;"><img src="servis/interfaces/gallery_lus/16.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus17_17"  style="display:none;"><img src="servis/interfaces/gallery_lus/17.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus18_18"  style="display:none;"><img src="servis/interfaces/gallery_lus/18.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus19_19"  style="display:none;"><img src="servis/interfaces/gallery_lus/19.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus20_20"  style="display:none;"><img src="servis/interfaces/gallery_lus/20.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus21_21"  style="display:none;"><img src="servis/interfaces/gallery_lus/21.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus22_22"  style="display:none;"><img src="servis/interfaces/gallery_lus/22.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus23_23"  style="display:none;"><img src="servis/interfaces/gallery_lus/23.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus24_24"  style="display:none;"><img src="servis/interfaces/gallery_lus/24.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus25_25"  style="display:none;"><img src="servis/interfaces/gallery_lus/25.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus26_26"  style="display:none;"><img src="servis/interfaces/gallery_lus/26.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus27_27"  style="display:none;"><img src="servis/interfaces/gallery_lus/27.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus28_28"  style="display:none;"><img src="servis/interfaces/gallery_lus/28.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus29_29"  style="display:none;"><img src="servis/interfaces/gallery_lus/29.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus30_30"  style="display:none;"><img src="servis/interfaces/gallery_lus/30.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus31_31"  style="display:none;"><img src="servis/interfaces/gallery_lus/31.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus33_33"  style="display:none;"><img src="servis/interfaces/gallery_lus/33.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus35_35"  style="display:none;"><img src="servis/interfaces/gallery_lus/35.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus36_36"  style="display:none;"><img src="servis/interfaces/gallery_lus/36.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus37_37"  style="display:none;"><img src="servis/interfaces/gallery_lus/37.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus38_38"  style="display:none;"><img src="servis/interfaces/gallery_lus/38.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus39_39"  style="display:none;"><img src="servis/interfaces/gallery_lus/39.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus40_40"  style="display:none;"><img src="servis/interfaces/gallery_lus/40.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus41_41"  style="display:none;"><img src="servis/interfaces/gallery_lus/41.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus42_42"  style="display:none;"><img src="servis/interfaces/gallery_lus/42.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus43_43"  style="display:none;"><img src="servis/interfaces/gallery_lus/43.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus44_44"  style="display:none;"><img src="servis/interfaces/gallery_lus/44.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus45_45"  style="display:none;"><img src="servis/interfaces/gallery_lus/45.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus46_46"  style="display:none;"><img src="servis/interfaces/gallery_lus/46.png" alt=""  width="130" height="" class="drag" /></div>'+
	'<div class="lus47_47"  style="display:none;"><img src="servis/interfaces/gallery_lus/47.png" alt=""  width="130" height="" class="drag" /></div>'+

'</div>'+

'<div class="overlay11"></div>'+
	'<div class="popup11">'+
		'<div class="close_window11 colorx">x</div>'+

			'<img src="servis/interfaces/gallery_lus/1.png" alt=""  width="50" height="50" class="lus1" />'+
			'<img src="servis/interfaces/gallery_lus/2.png" alt=""  width="50" height="50" class="lus2" />'+
			'<img src="servis/interfaces/gallery_lus/3.png" alt=""  width="50" height="50" class="lus3" />'+
			'<img src="servis/interfaces/gallery_lus/4.png" alt=""  width="50" height="50" class="lus4" />'+
			'<img src="servis/interfaces/gallery_lus/5.png" alt=""  width="50" height="50" class="lus5" />'+
			'<img src="servis/interfaces/gallery_lus/6.png" alt=""  width="50" height="50" class="lus6" />'+
			'<img src="servis/interfaces/gallery_lus/7.png" alt=""  width="50" height="50" class="lus7" />'+
			'<img src="servis/interfaces/gallery_lus/8.png" alt=""  width="50" height="50" class="lus8" />'+
			'<img src="servis/interfaces/gallery_lus/9.png" alt=""  width="50" height="50" class="lus9" />'+
			'<img src="servis/interfaces/gallery_lus/10.png" alt=""  width="50" height="50" class="lus10" />'+
			
			'<img src="servis/interfaces/gallery_lus/11.png" alt=""  width="50" height="50" class="lus11" />'+
			'<img src="servis/interfaces/gallery_lus/12.png" alt=""  width="50" height="50" class="lus12" />'+
			'<img src="servis/interfaces/gallery_lus/13.png" alt=""  width="50" height="50" class="lus13" />'+
			'<img src="servis/interfaces/gallery_lus/14.png" alt=""  width="50" height="50" class="lus14" />'+
			'<img src="servis/interfaces/gallery_lus/15.png" alt=""  width="50" height="50" class="lus15" />'+
			'<img src="servis/interfaces/gallery_lus/16.png" alt=""  width="50" height="50" class="lus16" />'+
			'<img src="servis/interfaces/gallery_lus/17.png" alt=""  width="50" height="50" class="lus17" />'+
			'<img src="servis/interfaces/gallery_lus/18.png" alt=""  width="50" height="50" class="lus18" />'+
			'<img src="servis/interfaces/gallery_lus/19.png" alt=""  width="50" height="50" class="lus19" />'+
			'<img src="servis/interfaces/gallery_lus/20.png" alt=""  width="50" height="50" class="lus20" />'+
			
			'<img src="servis/interfaces/gallery_lus/21.png" alt=""  width="50" height="50" class="lus21" />'+
			'<img src="servis/interfaces/gallery_lus/22.png" alt=""  width="50" height="50" class="lus22" />'+
			'<img src="servis/interfaces/gallery_lus/23.png" alt=""  width="50" height="50" class="lus23" />'+
			'<img src="servis/interfaces/gallery_lus/24.png" alt=""  width="50" height="50" class="lus24" />'+
			'<img src="servis/interfaces/gallery_lus/25.png" alt=""  width="50" height="50" class="lus25" />'+
			'<img src="servis/interfaces/gallery_lus/26.png" alt=""  width="50" height="50" class="lus26" />'+
			'<img src="servis/interfaces/gallery_lus/27.png" alt=""  width="50" height="50" class="lus27" />'+
			'<img src="servis/interfaces/gallery_lus/28.png" alt=""  width="50" height="50" class="lus28" />'+
			'<img src="servis/interfaces/gallery_lus/29.png" alt=""  width="50" height="50" class="lus29" />'+
			'<img src="servis/interfaces/gallery_lus/30.png" alt=""  width="50" height="50" class="lus30" />'+
			
			'<img src="servis/interfaces/gallery_lus/31.png" alt=""  width="50" height="50" class="lus31" />'+

			'<img src="servis/interfaces/gallery_lus/33.png" alt=""  width="50" height="50" class="lus33" />'+

			'<img src="servis/interfaces/gallery_lus/35.png" alt=""  width="50" height="50" class="lus35" />'+
			'<img src="servis/interfaces/gallery_lus/36.png" alt=""  width="50" height="50" class="lus36" />'+
			'<img src="servis/interfaces/gallery_lus/37.png" alt=""  width="50" height="50" class="lus37" />'+
			'<img src="servis/interfaces/gallery_lus/38.png" alt=""  width="50" height="50" class="lus38" />'+
			'<img src="servis/interfaces/gallery_lus/39.png" alt=""  width="50" height="50" class="lus39" />'+
			'<img src="servis/interfaces/gallery_lus/40.png" alt=""  width="50" height="50" class="lus40" />'+
			
			'<img src="servis/interfaces/gallery_lus/41.png" alt=""  width="50" height="50" class="lus41" />'+
			'<img src="servis/interfaces/gallery_lus/42.png" alt=""  width="50" height="50" class="lus42" />'+
			'<img src="servis/interfaces/gallery_lus/43.png" alt=""  width="50" height="50" class="lus43" />'+
			'<img src="servis/interfaces/gallery_lus/44.png" alt=""  width="50" height="50" class="lus44" />'+
			'<img src="servis/interfaces/gallery_lus/45.png" alt=""  width="50" height="50" class="lus45" />'+
			'<img src="servis/interfaces/gallery_lus/46.png" alt=""  width="50" height="50" class="lus46" />'+
			'<img src="servis/interfaces/gallery_lus/47.png" alt=""  width="50" height="50" class="lus47" />'+
			
			
		'</div>'+

			$(document).ready(function(){ 
			
				$('.lus1').click(function (){ $('.lus1_1, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus2').click(function (){ $('.lus2_2, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });
				$('.lus3').click(function (){ $('.lus3_3, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus4').click(function (){ $('.lus4_4, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus5').click(function (){ $('.lus5_5, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus6').click(function (){ $('.lus6_6, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus7').click(function (){ $('.lus7_7, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });
				$('.lus8').click(function (){ $('.lus8_8, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus9').click(function (){ $('.lus9_9, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus10').click(function (){ $('.lus10_10, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				
				$('.lus11').click(function (){ $('.lus11_11, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus12').click(function (){ $('.lus12_12, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });
				$('.lus13').click(function (){ $('.lus13_13, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus14').click(function (){ $('.lus14_14, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus15').click(function (){ $('.lus15_15, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus16').click(function (){ $('.lus16_16, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus17').click(function (){ $('.lus17_17, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });
				$('.lus18').click(function (){ $('.lus18_18, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus19').click(function (){ $('.lus19_19, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus20').click(function (){ $('.lus20_20, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				
				$('.lus21').click(function (){ $('.lus21_21, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus22').click(function (){ $('.lus22_22, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });
				$('.lus23').click(function (){ $('.lus23_23, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus24').click(function (){ $('.lus24_24, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus25').click(function (){ $('.lus25_25, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus26').click(function (){ $('.lus26_26, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus27').click(function (){ $('.lus27_27, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });
				$('.lus28').click(function (){ $('.lus28_28, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus29').click(function (){ $('.lus29_29, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus30').click(function (){ $('.lus30_30, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });

				$('.lus31').click(function (){ $('.lus31_31, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				
				$('.lus33').click(function (){ $('.lus33_33, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				
				$('.lus35').click(function (){ $('.lus35_35, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus36').click(function (){ $('.lus36_36, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus37').click(function (){ $('.lus37_37, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });
				$('.lus38').click(function (){ $('.lus38_38, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus39').click(function (){ $('.lus39_39, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus40').click(function (){ $('.lus40_40, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 

				$('.lus41').click(function (){ $('.lus41_41, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus42').click(function (){ $('.lus42_42, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });
				$('.lus43').click(function (){ $('.lus43_43, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus44').click(function (){ $('.lus44_44, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus45').click(function (){ $('.lus45_45, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus46').click(function (){ $('.lus46_46, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); }); 
				$('.lus47').click(function (){ $('.lus47_47, .close_lus').css({'display':'block'}); $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });				

				$('.close_lus, a.open_window11').click(function (){ $(' .lus1_1, .lus2_2, .lus3_3, .lus4_4, .lus5_5, .lus6_6, .lus7_7, .lus8_8, .lus9_9, .lus10_10, .lus11_11, .lus12_12, .lus13_13, .lus14_14, .lus15_15, .lus16_16, .lus17_17, .lus18_18, .lus19_19, .lus20_20, .lus21_21, .lus22_22, .lus23_23, .lus24_24, .lus25_25, .lus26_26, .lus27_27, .lus28_28, .lus29_29, .lus30_30, .lus31_31, .lus33_33, .lus35_35, .lus36_36, .lus37_37, .lus38_38, .lus39_39, .lus40_40, .lus41_41, .lus42_42, .lus43_43, .lus44_44, .lus45_45, .lus46_46, .lus47_47, .close_lus' ).css({'display':'none'}); }); 


				$('a.open_window11').click(function (){ $('.popup11, .overlay11').css({'display':'block', 'visibility':'visible'}); });
				$('.close_window11').click(function (){ $('.popup11, .overlay11').css({'display':'none', 'visibility':'hidden'}); });

			});