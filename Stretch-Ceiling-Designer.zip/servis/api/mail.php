<?php

	header ("Content-Type: text/html; charset=utf-8");
	
	$to = "veryline@mail.ru"; //получатель уведомлений
	
	$HTTP_HOST = parse_url ("http://".$_SERVER["HTTP_HOST"]); 
	$HTTP_HOST = str_replace (array ("http://","www."), "", $HTTP_HOST["host"]);
	$from = "".$HTTP_HOST;
	$HTTP_HOST = $_SERVER["HTTP_HOST"];

	$squ = $_POST['squ'];
	$name = $_POST['name'];
	$phone = $_POST['phone'];

	$message = "
		<p style='font-family: Arial,Helvetica,sans-serif;font-size: 14px;text-align: center;'><i>Информация о заказе:</i></p>
		<hr>
		<p style='line-height: 30px;'>
			Площадь: $squ <br/>
			Имя: $name <br/>
			Телефон: $phone <br/>
		</p>
		<hr>
		<br>
		<div style='margin:0 auto;width:200px;position:relative;top:-10px;'><img src='https://pp.userapi.com/c836138/v836138585/2bdf8/oDZMS_1vMzE.jpg' width='200'  /></div>
		<br>
		<center><h4>Веб-студия VERYLINE</h4></center>
	";
	
	
	$subject = '=?UTF-8?B?'.base64_encode('ЗАКАЗАН ОБРАТНЫЙ ЗВОНОК').'?=';  
	$headers .= "Content-type: text/html; charset=utf-8\r\n"; 
	$headers .= "From: VERYLINE <".$from.">"; 
	$send = mail ($to, $subject, $message, $headers);
	if ($send == 'true') {
		echo '
			<div id="message">
				<h2>VERYLINE</h2>
				<p class="success">Спасибо! Ваша заявка принята!</p><br />
				<p class="constructor">Конструкторы для вашего бизнеса</p>
			</div>
		';
    }else {
		echo '<center><p class="error"><b>Ошибка.<br /> Сообщение не отправлено!</b></p></center>';
    }
 
?>