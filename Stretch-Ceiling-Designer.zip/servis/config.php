<?php

	$PASSWORD = 'A000000001';
	
	$URL = 'constructor-version-13.ru';
	$COPYRIGHTED = 'constructor-version-13.ru';

	$LANGUAGE = 'russian';
	$TEMPLATE = 'template_2';
	$PALITRA = 'lackfolie';

	$CANVASWIDTH = '950'; // 800 Ширина окна CANVAS
	$CANVASHEIGHT = '625'; // 620 Высота окна CANVAS

	$WIDTH = '938';   // Ширина окна штриховки
	$HEIGHT = '615'; // Высота окна штриховки

	$FILESIZE = '5'; // Размер загружаемой фотографии в MB
	$UPLOAD_TYPE = 'jpeg|jpg|png|gif';

	$CIRCULRADIUS = '1';
	$CIRCULCOLOR = 'red';
	$POLYGONCOLOR = 'red';


	$baseurl = "//$URL/servis/";
	require_once("lang/$LANGUAGE.php");


	$SERVER_NAME = $_SERVER['SERVER_NAME'];

	$ACCESSHOST = "console.log('$BREAKING');";
	
	function accesshost(){
		if($_SERVER['SERVER_NAME'] == 'constructor-version-13.ru') 
			return true; 
		else 
			return false; 
	};

?>  
