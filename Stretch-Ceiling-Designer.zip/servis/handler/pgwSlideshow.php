<?php
	$dir = 'save/output/';
	$files = scandir($dir);
	for ($i = 0; $i < count($files); $i++) {
		if (($files[$i] != ".") && ($files[$i] != "..")) {
			$path = $dir.$files[$i];
			$ext = substr(strrchr($path, '.'), 1);
		}
		if($ext == 'png'){
			$mass[$i]="$path";
		}else{
			continue;
		}
	}
	echo json_encode($mass);
	exit;
?>