<?
require_once('../config.php');

function myscandir($dir, $sort=0) {
    $list = scandir($dir, $sort);
    // если директории не существует
    if (!$list) return false;
    // удаляем . и .. (я думаю редко кто использует)
    if ($sort == 0) unset($list[0],$list[1]);
    else unset($list[count($list)-1], $list[count($list)-1]);
    return $list;
}
$dir = 'gallery';
$files1 = myscandir($dir);

$px_w = 42* (count($files1)+1);
?>
<div class="gallery_view">
	<div class="gallery_slide">
		<div class="galler_slide_view">
			<ul style="width:<? echo $px_w;?>px;">
				<? 	for ($i=0; $i <= count($files1)+1; $i++) { 
						if(strlen($files1[$i])>3){
							?>
							<li data-index="A<? echo $i; ?>" data-image="<? echo $baseurl; ?>interfaces/gallery/<? echo $files1[$i]; ?>" style="background-image:url('<? echo $baseurl; ?>interfaces/gallery/<? echo $files1[$i]; ?>');"></li>
							<?
						}
					} ?>
			</ul>
		</div>
		<div class="galler_slide_control">
			<button class="gallery-next"><i class="fa fa-angle-double-right"></i></button>
			<button class="gallery-prev"><i class="fa fa-angle-double-left"></i></button>
		</div>
	</div>
	<div class="gallery_user">
		<div class="image-upload">
			<i class="fa fa-picture-o"></i>
            <label>
            	<input id="new_image" type="file" name="file">
            	<span><?=$DOWNLOAD_YOUR_OWN;?><br/>картинку</span>
            </label>
		</div>
	</div>