<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'اختيار على الانترنت من اللون تمتد السقف ';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'التقاط صورة من السقف الخاص بك وتحميلها على هذا التطبيق ';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'تحميل صورة الغرفة الخاصة بك ';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'اختيار غرفة من المعرض ';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'حدد المنطقة المرئية من السقف ببساطة عن طريق النقر على الزوايا ';
$ALL_CLEAR = 																	'كل شيء واضح ';
$ATTENTION = 																	'اهتمام! ';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. انقر على "قلم رصاص" لبدء اختيار منطقة السقف. ';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. لحذف المنطقة المحددة، انقر على "المهملات" ';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. عند اكتمال اختيار النقر المزدوج. ';
$APPLY = 																		'تطبق ';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'معرفة تكلفة مثل هذا السقف ';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'ترك أمر والحصول على حساب ';
$ENTER_THE_CEILING_AREA = 														'أدخل مساحة السقف ';
$ENTER_YOUR_NAME = 																'أدخل اسمك ';
$ENTER_TELEPHONE_NUMBER = 														'أدخل رقم الهاتف ';
$GETTING_CALCULATING_IN_SMS = 													'الحصول على حساب في الرسائل القصيرة ';
$PRIVACY_POLICY = 																'سياسة الخصوصية ';
$SAVE_THE_IMAGE = 																'حفظ الصورة ';
$CHANDELIER = 																	'الثريا ';
$CATALOG = 										'التصور من تمتد سقف ';
$GLOSSY = 																		'لامع ';
$MATTED = 																		'ممل ';
$SATINE = 																		'صقيل ';
$YOUR_CHOICE = 																	'اختيارك ';
$YOUR_CHOICE_PHOTO_PRINT = 														'اختيارك: طباعة الصور № ';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'اختيارك: طباعة الصور الخاصة بك ';
$NO_DOWNLOAD_ITEM = 															'لا تحميل البند ';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'المتصفح لا يدعم تحميل الصور ';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'لم يتم تحديد ملف للتحميل ';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'يجب أن تكون الصورة بتنسيق جبغ أو ينغ أو جيف ';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'يجب ألا يتجاوز حجم الصورة 5 ميغابايت ';
$BACK = 																		'منذ ';
$DOWNLOAD_YOUR_OWN = 															'تحميل ';
$PHOTOSHOP = 																	'طباعة الصور ';
$HALL =																			'قاعة ';
$BEDROOM =																		'غرفة نوم ';
$CHILDREN =																		'حضانة ';
$LIVING_ROOM =																	'غرفة المعيشة ';
$KITCHEN =																		'مطبخ ';
$ENTRANCE_HALL =																'مدخل ';
$BATHROOM =																		'حمام';

?> 