<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'онлайн падбор колеру нацяжной столі';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'сфатаграфуйце свой столь і загрузіце у гэта дадатак';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'загрузіць сваё фота памяшкання';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'выбраць памяшканне з галерэі';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'вылучыце бачную вобласць столі проста клікаючы мышкай па кутах';
$ALL_CLEAR = 																	'усё зразумела';
$ATTENTION = 																	'увага!';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. націсніце "аловак" для пачатку вылучэння вобласці столі.'; 
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. для выдалення вылучанай вобласці націсніце "кошык"'; 
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. пасля заканчэння вылучэння двайны клік мышы.'; 
$APPLY = 																		'прымяніць';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'даведацца кошт такой столі';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'пакіньце заяўку і атрымаеце разліках';
$ENTER_THE_CEILING_AREA = 														'увядзіце пляц столі';
$ENTER_YOUR_NAME = 																'увядзіце сваё імя';
$ENTER_TELEPHONE_NUMBER = 														'ўвядзіце нумар тэлефона';
$GETTING_CALCULATING_IN_SMS = 													'атрымаць разліках у смс';
$PRIVACY_POLICY = 																'палітыка прыватнасці';
$SAVE_THE_IMAGE = 																'захаваць малюнак';
$CHANDELIER = 																	'люстра';
$CATALOG = 										'візуалізацыя нацяжной столі';
$GLOSSY = 																		'глянцавы';
$MATTED = 																		'матавы';
$SATINE = 																		'сацінавы';
$YOUR_CHOICE = 																	'ваш выбар';
$YOUR_CHOICE_PHOTO_PRINT = 														'ваш выбар: фотадрук №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'ваш выбар: свая фотадрук';
$NO_DOWNLOAD_ITEM = 															'няма элемента загрузкі';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'браўзэр не падтрымлівае загруку фота';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'не абраны файл для загрузкі';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'фатаграфія павінна быць у фармаце jpg, png ці gif';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'памер фатаграфіі не павінен перавышаць 5 мб';
$BACK = 																		'назад';
$DOWNLOAD_YOUR_OWN = 															'загрузіць сваю';
$PHOTOSHOP = 																	'фотадрук';
$HALL =																			'зала';
$BEDROOM =																		'спальня';
$CHILDREN =																		'дзіцячая';
$LIVING_ROOM =																	'гасцёўня';
$KITCHEN =																		'кухня';
$ENTRANCE_HALL =																'пярэдні пакой';
$BATHROOM =																		'ванная';

?> 