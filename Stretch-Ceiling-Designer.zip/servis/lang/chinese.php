<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'在线选择彩色拉伸天花板';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'拍摄您的天花板的照片并上传到此应用程序';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'上传你的房间照片';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'从画廊选择一个房间';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'通过点击角落选择天花板的可见区域';
$ALL_CLEAR = 																	'一切都很清楚';
$ATTENTION = 																	'注意！';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1.点击“铅笔”开始选择天花板面积。';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2.要删除所选区域，请单击“垃圾桶”';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3.双击选择完成后。';
$APPLY = 																		'申请';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'找出这样一个上限的成本';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'下订单并得到一个计算';
$ENTER_THE_CEILING_AREA = 														'进入天花板的区域';
$ENTER_YOUR_NAME = 																'输入您的姓名';
$ENTER_TELEPHONE_NUMBER = 														'输入电话号码';
$GETTING_CALCULATING_IN_SMS = 													'以短信计算';
$PRIVACY_POLICY = 																'隐私政策';
$SAVE_THE_IMAGE = 																'保存图像';
$CHANDELIER = 																	'吊灯';
$CATALOG = 										'拉伸天花板的可视化';
$GLOSSY = 																		'光滑';
$MATTED = 																		'平淡';
$SATINE = 																		'缎子';
$YOUR_CHOICE = 																	'你的选择';
$YOUR_CHOICE_PHOTO_PRINT = 														'你的选择：照片打印№';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'你的选择：你的照片打印';
$NO_DOWNLOAD_ITEM = 															'没有下载项目';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'浏览器不支持上传照片';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'没有选择要上传的文件';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'照片必须是jpg，png或gif格式';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'照片的大小不应超过5 mb';
$BACK = 																		'前';
$DOWNLOAD_YOUR_OWN = 															'上传你的';
$PHOTOSHOP = 																	'照片打印';
$HALL =																			'大厅';
$BEDROOM =																		'卧室';
$CHILDREN =																		'苗圃';
$LIVING_ROOM =																	'客厅';
$KITCHEN =																		'厨房';
$ENTRANCE_HALL =																'门厅';
$BATHROOM =																		'浴室';

?> 