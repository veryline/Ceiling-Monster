<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'online selection of color stretch ceiling';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'take a picture of your ceiling and upload to this app ';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'upload your room photo ';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'choose a room from the gallery ';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'Select the visible area of ​​the ceiling simply by clicking on the corners ';
$ALL_CLEAR = 																	'all clear ';
$ATTENTION = 																	'Attention! ';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. Click the "pencil" to start the selection of the ceiling area. ';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. To delete the selected area, click on the "Trash" ';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. When the double-click selection is complete. ';
$APPLY = 																		'apply ';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'find out the cost of such a ceiling ';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'leave an order and get a calculation ';
$ENTER_THE_CEILING_AREA = 														'enter the area of ​​the ceiling ';
$ENTER_YOUR_NAME = 																'enter your name ';
$ENTER_TELEPHONE_NUMBER = 														'enter phone number ';
$GETTING_CALCULATING_IN_SMS = 													'get the calculation in sms ';
$PRIVACY_POLICY = 																'Privacy Policy ';
$SAVE_THE_IMAGE = 																'save image ';
$CHANDELIER = 																	'chandelier ';
$CATALOG = 										'visualization of stretch ceiling ';
$GLOSSY = 																		'glossy ';
$MATTED = 																		'frosted ';
$SATINE = 																		'satin ';
$YOUR_CHOICE = 																	'your choice ';
$YOUR_CHOICE_PHOTO_PRINT = 														'your choice: photo printing № ';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'your choice: your photo printing ';
$NO_DOWNLOAD_ITEM = 															'no download item ';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'the browser does not support uploading photos ';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'no file selected for upload ';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'The photo must be in jpg, png or gif format ';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'the size of the photo should not exceed 5 mb ';
$BACK = 																		'backward ';
$DOWNLOAD_YOUR_OWN = 															'upload your ';
$PHOTOSHOP = 																	'photo printing ';
$HALL =																			'Hall ';
$BEDROOM =																		'bedroom ';
$CHILDREN =																		'nursery ';
$LIVING_ROOM =																	'living room ';
$KITCHEN =																		'kitchen ';
$ENTRANCE_HALL =																'hallway ';
$BATHROOM =																		'bathroom';

?> 