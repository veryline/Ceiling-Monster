<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'Choix en ligne du plafond de couleur';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'prenez une photo de votre plafond et téléchargez-la sur cette application';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'téléchargez la photo de votre chambre';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'choisissez une pièce de la galerie';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'Sélectionnez la zone visible du plafond simplement en cliquant sur les coins';
$ALL_CLEAR = 																	'tout est clair';
$ATTENTION = 																	'attention!';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. Cliquez sur le "crayon" pour commencer la sélection de la zone de plafond.';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. Pour supprimer la zone sélectionnée, cliquez sur "Trash"';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. Lorsque la sélection de double-clic est terminée.';
$APPLY = 																		'appliquer';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'découvrez le coût d"un tel plafond';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'laisser une commande et obtenir un calcul';
$ENTER_THE_CEILING_AREA = 														'entrer dans la zone du plafond';
$ENTER_YOUR_NAME = 																'Entrez votre nom';
$ENTER_TELEPHONE_NUMBER = 														'Entrez le numéro de téléphone';
$GETTING_CALCULATING_IN_SMS = 													'obtenir le calcul en sms';
$PRIVACY_POLICY = 																'politique de confidentialité';
$SAVE_THE_IMAGE = 																'enregistrer l"image"';
$CHANDELIER = 																	'lustre';
$CATALOG = 										'Visualisation du plafond étirable';
$GLOSSY = 																		'brillant';
$MATTED = 																		'givré';
$SATINE = 																		'satin';
$YOUR_CHOICE = 																	'votre choix';
$YOUR_CHOICE_PHOTO_PRINT = 														'votre choix: impression photo №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'votre choix: votre impression photo';
$NO_DOWNLOAD_ITEM = 															'article sans téléchargement';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'le navigateur ne prend pas en charge le téléchargement de photos';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'aucun fichier sélectionné pour le téléchargement';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'La photo doit être en format jpg, png ou gif';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'la taille de la photo ne doit pas dépasser 5 mb';
$BACK = 																		'vers l"arrière';
$DOWNLOAD_YOUR_OWN = 															'téléchargez votre';
$PHOTOSHOP = 																	'impression photo';
$HALL =																			'chambre';
$BEDROOM =																		'chambre à coucher';
$CHILDREN =																		'pépinière';
$LIVING_ROOM =																	'salle de séjour';
$KITCHEN =																		'cuisine';
$ENTRANCE_HALL =																'couloir';
$BATHROOM =																		'salle de bain';

?> 