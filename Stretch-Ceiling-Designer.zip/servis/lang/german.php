<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'Online-Auswahl der Farbstretch-Decke';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'nehmen Sie ein Bild von Ihrer Decke und laden Sie auf diese App';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'lade dein Zimmerfoto hoch';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'wähle ein Zimmer aus der Galerie';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'Wählen Sie den sichtbaren Bereich der Decke einfach durch einen Klick auf die Ecken';
$ALL_CLEAR = 																	'alles klar';
$ATTENTION = 																	'Aufmerksamkeit!';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. Klicken Sie auf den "Bleistift", um die Auswahl des Deckenbereichs zu starten.';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. Um den ausgewählten Bereich zu löschen, klicken Sie auf den "Papierkorb"';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. Wenn die Doppelklick-Auswahl abgeschlossen ist.';
$APPLY = 																		'anwenden';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'finde die Kosten einer solchen Decke';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'eine Bestellung abgeben und eine Kalkulation erhalten';
$ENTER_THE_CEILING_AREA = 														'betreten den Bereich der Decke';
$ENTER_YOUR_NAME = 																'Geben Sie Ihren Namen ein';
$ENTER_TELEPHONE_NUMBER = 														'Rufnummer eingeben';
$GETTING_CALCULATING_IN_SMS = 													'die Berechnung in sms erhalten';
$PRIVACY_POLICY = 																'Datenschutzerklärung';
$SAVE_THE_IMAGE = 																'Bild speichern';
$CHANDELIER = 																	'kronleuchter';
$CATALOG = 										'Visualisierung der Deckendecke';
$GLOSSY = 																		'glänzend';
$MATTED = 																		'mattiert';
$SATINE = 																		'satin';
$YOUR_CHOICE = 																	'Ihre Wahl';
$YOUR_CHOICE_PHOTO_PRINT = 														'Ihre Wahl: Fotodruck №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'Ihre Wahl: Ihr Fotodruck';
$NO_DOWNLOAD_ITEM = 															'kein Downloadartikel';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'Der Browser unterstützt das Hochladen von Fotos nicht';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'Keine Datei zum Hochladen ausgewählt';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'Das Foto muss im jpg-, png- oder gif-Format sein';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'Die Größe des Fotos darf 5 mb nicht überschreiten';
$BACK = 																		'zurück';
$DOWNLOAD_YOUR_OWN = 															'lade deine';
$PHOTOSHOP = 																	'Fotodruck';
$HALL =																			'zimmer';
$BEDROOM =																		'schlafzimmer';
$CHILDREN =																		'Kindergarten';
$LIVING_ROOM =																	'Wohnzimmer';
$KITCHEN =																		'Küche';
$ENTRANCE_HALL =																'Flur';
$BATHROOM =																		'Badezimmer';

?> 