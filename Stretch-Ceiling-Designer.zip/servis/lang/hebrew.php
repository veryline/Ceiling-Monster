<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'מבחר מקוון של תקרת מתיחה צבע';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'צלם תמונה של התקרה שלך וטען אותה לאפליקציה הזו';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'העלה את תמונת החדר שלך';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'בחר חדר מהגלריה';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'בחר את האזור הגלוי של התקרה פשוט על ידי לחיצה על הפינות';
$ALL_CLEAR = 																	'הכל ברור';
$ATTENTION = 																	'תשומת לב!';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. לחץ על "עיפרון" כדי להתחיל את הבחירה של אזור התקרה.';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. כדי למחוק את האזור שנבחר, לחץ על "אשפה"';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'.3 לאחר השלמת הבחירה בלחיצה כפולה.';
$APPLY = 																		'להג';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'לברר את העלות של תקרה כזו';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'להשאיר הזמנה ולקבל חישוב';
$ENTER_THE_CEILING_AREA = 														'להיכנס לאזור התקרה';
$ENTER_YOUR_NAME = 																'הזן את שמך';
$ENTER_TELEPHONE_NUMBER = 														'הזן מספר טלפון';
$GETTING_CALCULATING_IN_SMS = 													'לקבל את החישוב ב - SMS';
$PRIVACY_POLICY = 																'מדיניות הפרטיות';
$SAVE_THE_IMAGE = 																'לשמור תמונה';
$CHANDELIER = 																	'נברשת';
$CATALOG = 																		'הדמיה של תקרה מתיחה';
$GLOSSY = 																		'מבריק';
$MATTED = 																		'כפור';
$SATINE = 																		'סאטן';
$YOUR_CHOICE = 																	'הבחירה שלך';
$YOUR_CHOICE_PHOTO_PRINT = 														'הבחירה שלך: photo printing №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'על פי בחירתך: הדפסת התמונות שלך';
$NO_DOWNLOAD_ITEM = 															'אין פריט הורדה';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'הדפדפן אינו תומך בהעלאת תמונות';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'לא נבחר קובץ להעלאה';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'התמונה חייבת להיות בפורמט jpg, png או gif';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'הגודל של התמונה לא יעלה על 5 MB';
$BACK = 																		'אחורה';
$DOWNLOAD_YOUR_OWN = 															'העלה את';
$PHOTOSHOP = 																	'הדפסת צילומים';
$HALL =																			'חדר';
$BEDROOM =																		'חדר שינה';
$CHILDREN =																		'משתלה';
$LIVING_ROOM =																	'סלון';
$KITCHEN =																		'מטבח';
$ENTRANCE_HALL =																'מסדרון';
$BATHROOM =																		'חדר אמבטיה';

?> 