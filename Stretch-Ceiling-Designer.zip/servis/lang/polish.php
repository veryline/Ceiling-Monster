<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'online wybór kolorystycznego sufitu';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'zrób zdjęcie swojego sufitu i prześlij do tej aplikacji';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'przesłać zdjęcie pokoju';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'wybierz pokój z galerii';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'Wybierz widoczny obszar sufitu po prostu klikając na rogach';
$ALL_CLEAR = 																	'wszystko jest jasne';
$ATTENTION = 																	'uwaga!';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. Kliknij "Ołówek", aby rozpocząć wybór obszaru sufitu.';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. Aby usunąć wybrany obszar, kliknij na "Kosz"';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. Po zakończeniu dwukrotnego wyboru.';
$APPLY = 																		'zastosować';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'sprawdź koszt takiego sufitu';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'opuścić zamówienie i otrzymać obliczenia';
$ENTER_THE_CEILING_AREA = 														'wejdź w obszar sufitu';
$ENTER_YOUR_NAME = 																'wprowadź swoje imię';
$ENTER_TELEPHONE_NUMBER = 														'wprowadź numer telefonu';
$GETTING_CALCULATING_IN_SMS = 													'obliczyć w sms';
$PRIVACY_POLICY = 																'polityka prywatności';
$SAVE_THE_IMAGE = 																'Zapisz obraz';
$CHANDELIER = 																	'żyrandol';
$CATALOG = 																		'wizualizacja sufitu napinającego';
$GLOSSY = 																		'błyszczący';
$MATTED = 																		'oszroniony';
$SATINE = 																		'satyna';
$YOUR_CHOICE = 																	'Twój wybór';
$YOUR_CHOICE_PHOTO_PRINT = 														'Twój wybór: druk fotografii №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'Twój wybór: drukowanie zdjęć';
$NO_DOWNLOAD_ITEM = 															'bez elementu do pobrania';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'przeglądarka nie obsługuje przesyłania zdjęć';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'nie wybrano pliku do przesłania';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'Zdjęcie musi być w formacie jpg, png lub gif';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'rozmiar zdjęcia nie powinien przekraczać 5 mb';
$BACK = 																		'do tyłu';
$DOWNLOAD_YOUR_OWN = 															'przesłać swoje';
$PHOTOSHOP = 																	'drukowanie zdjęć';
$HALL =																			'pokój';
$BEDROOM =																		'sypialnia';
$CHILDREN =																		'przedszkole';
$LIVING_ROOM =																	'pokój dzienny';
$KITCHEN =																		'kuchnia';
$ENTRANCE_HALL =																'korytarz';
$BATHROOM =																		'łazienka';

?> 