<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'selectarea online a tavanului color stretch';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'faceți o fotografie a plafonului dvs. și încărcați-o în această aplicație';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'încărcați fotografia camerei';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'alegeți o cameră din galerie';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'Selectați zona vizibilă a tavanului făcând clic pe colțuri';
$ALL_CLEAR = 																	'totul este clar';
$ATTENTION = 																	'Atenție!';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. Faceți clic pe "creion" pentru a începe selectarea zonei de plafon.';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. Pentru a șterge zona selectată, faceți clic pe "Coșul de gunoi"';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. Când selecția cu dublu clic este finalizată.';
$APPLY = 																		'aplica';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'aflați costul unui astfel de plafon';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'lăsați o comandă și obțineți un calcul';
$ENTER_THE_CEILING_AREA = 														'intrați în zona plafonului';
$ENTER_YOUR_NAME = 																'introduceți numele dvs.';
$ENTER_TELEPHONE_NUMBER = 														'introduceți numărul de telefon';
$GETTING_CALCULATING_IN_SMS = 													'obțineți calculul în sms';
$PRIVACY_POLICY = 																'politica de confidențialitate';
$SAVE_THE_IMAGE = 																'salvați imaginea';
$CHANDELIER = 																	'candelabru';
$CATALOG = 										'vizualizarea plafonului stretch';
$GLOSSY = 																		'lucios';
$MATTED = 																		'plictisitor';
$SATINE = 																		'satin';
$YOUR_CHOICE = 																	'alegerea ta';
$YOUR_CHOICE_PHOTO_PRINT = 														'alegerea ta: imprimarea fotografiilor №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'alegerea dvs.: imprimarea fotografiilor';
$NO_DOWNLOAD_ITEM = 															'nici un element de descărcare';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'browserul nu acceptă încărcarea fotografiilor';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'niciun fișier selectat pentru încărcare';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'Fotografia trebuie să fie în format jpg, png sau gif';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'dimensiunea fotografiei nu trebuie să depășească 5 mb';
$BACK = 																		'în urmă';
$DOWNLOAD_YOUR_OWN = 															'încărcați-vă';
$PHOTOSHOP = 																	'imprimare foto';
$HALL =																			'hol';
$BEDROOM =																		'dormitor';
$CHILDREN =																		'pepinieră';
$LIVING_ROOM =																	'camera de zi';
$KITCHEN =																		'bucătărie';
$ENTRANCE_HALL =																'coridor';
$BATHROOM =																		'baie';

?> 