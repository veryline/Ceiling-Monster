<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'онлайн подбор цвета натяжного потолка';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'сфотографируйте свой потолок и загрузите в это приложение';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'загрузить свое фото помещения';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'выбрать помещение из галереи';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'выделите видимую область потолка просто кликая мышкой по углам';
$ALL_CLEAR = 																	'все понятно';
$ATTENTION = 																	'внимание!';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. нажмите "карандаш" для начала выделения области потолка.';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. для удаления выделенной области нажмите "корзину"';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. по окончании выделения двойной клик мыши.';
$APPLY = 																		'применить';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'узнать стоимость такого потолка';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'оставьте заявку и получите рассчет';
$ENTER_THE_CEILING_AREA = 														'введите площадь потолка';
$ENTER_YOUR_NAME = 																'введите свое имя';
$ENTER_TELEPHONE_NUMBER = 														'введите номер телефона';
$GETTING_CALCULATING_IN_SMS = 													'получить рассчет в смс';
$PRIVACY_POLICY = 																'политика конфиденциальности';
$SAVE_THE_IMAGE = 																'сохранить изображение';
$CHANDELIER = 																	'люстра';
$CATALOG = 																		'каталог';
$GLOSSY = 																		'глянцевый';
$MATTED = 																		'матовый';
$SATINE = 																		'сатиновый';
$YOUR_CHOICE = 																	'ваш выбор';
$YOUR_CHOICE_PHOTO_PRINT = 														'ваш выбор: фотопечать №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'ваш выбор: своя фотопечать';
$NO_DOWNLOAD_ITEM = 															'нет элемента загрузки';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'браузер не поддерживает загруку фото';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'не выбран файл для загрузки';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'фотография должна быть в формате jpg, png или gif';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED = 										'размер фотографии не должен превышать';
$BACK = 																		'назад';
$DOWNLOAD_YOUR_OWN = 															'загрузить свою';
$PHOTOSHOP = 																	'фотопечать';
$PICTURE = 																		'картинку';
$HALL =																			'зал';			
$BEDROOM =																		'спальня';		
$CHILDREN =																		'детская';		
$LIVING_ROOM =																	'гостинная';
$KITCHEN =																		'кухня';		
$ENTRANCE_HALL =																'прихожая';	
$BATHROOM =																		'ванная';	


$BREAKING = 'Данный виджет защищен сертификатом безопасности, дальнейший взлом несет за вами ответстветвенность согласно статье 5 пунк 6 РФ';
?> 