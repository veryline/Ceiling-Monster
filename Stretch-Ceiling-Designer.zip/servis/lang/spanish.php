<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'Selección en línea de techos de color';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'tomar una foto de su techo y subir a esta aplicación';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'cargue la foto de su habitación';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'elegir una habitación de la galería';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'Seleccione el área visible del techo simplemente haciendo clic en las esquinas';
$ALL_CLEAR = 																	'todo está claro';
$ATTENTION = 																	'atención';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. Haga clic en el "lápiz" para iniciar la selección del área del techo.';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. Para eliminar el área seleccionada, haga clic en "Papelera"';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. Cuando se haya completado la selección de doble clic.';
$APPLY = 																		'aplicar';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'conocer el costo de dicho techo';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'dejar un pedido y obtener un cálculo';
$ENTER_THE_CEILING_AREA = 														'entrar en el área del techo';
$ENTER_YOUR_NAME = 																'ingresa tu nombre';
$ENTER_TELEPHONE_NUMBER = 														'ingresar número de teléfono';
$GETTING_CALCULATING_IN_SMS = 													'obtener el cálculo en sms';
$PRIVACY_POLICY = 																'política de privacidad';
$SAVE_THE_IMAGE = 																'guardar imagen';
$CHANDELIER = 																	'candelabro';
$CATALOG = 										'visualización del techo extensible';
$GLOSSY = 																		'brillante';
$MATTED = 																		'helado';
$SATINE = 																		'satén';
$YOUR_CHOICE = 																	'tu elección';
$YOUR_CHOICE_PHOTO_PRINT = 														'su elección: impresión de fotos №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'su elección: su impresión fotográfica';
$NO_DOWNLOAD_ITEM = 															'sin elemento de descarga';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'el navegador no admite la carga de fotos';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'no se ha seleccionado ningún archivo para cargarlo';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'La foto debe estar en formato jpg, png o gif';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'el tamaño de la foto no debe exceder los 5 mb';
$BACK = 																		'atrasado';
$DOWNLOAD_YOUR_OWN = 															'cargue su';
$PHOTOSHOP = 																	'impresión de fotos';
$HALL =																			'habitación';
$BEDROOM =																		'dormitorio';
$CHILDREN =																		'vivero';
$LIVING_ROOM =																	'sala de estar';
$KITCHEN =																		'cocina';
$ENTRANCE_HALL =																'pasillo';
$BATHROOM =																		'cuarto de baño';

?> 