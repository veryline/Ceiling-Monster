<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'çevrimiçi renk streç tavan seçimi';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'tavanı bir resim çekip bu uygulamaya yükle';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'odanın fotoğrafını yükle';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'galeriden bir oda seç';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'Köşeleri tıklayarak tavanın görünür alanını seçin';
$ALL_CLEAR = 																	'herşey berraktır';
$ATTENTION = 																	'dikkat!';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. Tavan alanının seçimine başlamak için "kurşun kalem" i tıklayın.';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. Seçilen alanı silmek için "Çöp Kutusu"';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. Çift tıklama seçimi tamamlandığında.';
$APPLY = 																		'uygulamak';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'Böyle bir tavanın maliyetini öğrenmek';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'emir vermek ve hesaplamak';
$ENTER_THE_CEILING_AREA = 														'tavan alanını gir';
$ENTER_YOUR_NAME = 																'adını gir';
$ENTER_TELEPHONE_NUMBER = 														'telefon numarasını gir';
$GETTING_CALCULATING_IN_SMS = 													'hesaplamayı sms cinsinden al';
$PRIVACY_POLICY = 																'gizlilik politikası';
$SAVE_THE_IMAGE = 																'resmi kaydet';
$CHANDELIER = 																	'avize';
$CATALOG = 										'streç tavan görüntüsü';
$GLOSSY = 																		'parlak';
$MATTED = 																		'donuk';
$SATINE = 																		'saten';
$YOUR_CHOICE = 																	'seçiminiz';
$YOUR_CHOICE_PHOTO_PRINT = 														'seçiminiz: fotoğraf baskısı №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'seçiminiz: fotoğraf baskısı';
$NO_DOWNLOAD_ITEM = 															'karşıdan yükleme öğesi yok';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'tarayıcı fotoğraf yüklemeyi desteklemez';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'yükleme için seçilen dosya yok';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'Fotoğraf jpg, png veya gif formatında olmalıdır';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'fotoğrafın boyutu 5 mb"yi geçmemelidir';
$BACK = 																		'önce';
$DOWNLOAD_YOUR_OWN = 															'yükle';
$PHOTOSHOP = 																	'fotoğraf baskısı';
$HALL =																			'salon';
$BEDROOM =																		'yatak odası';
$CHILDREN =																		'kreş';
$LIVING_ROOM =																	'oturma odası';
$KITCHEN =																		'mutfak';
$ENTRANCE_HALL =																'koridor';
$BATHROOM =																		'banyo';

?> 