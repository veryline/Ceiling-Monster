<?php

$ONLINE_SELECTION_OF_STRETCH_CEILING_COLOR = 									'онлайн підбір кольору натяжної стелі';
$PHOTOGRAPH_YOUR_CEILING_AND_DOWNLOAD_THIS_APP = 								'сфотографуйте свою стелю і завантажте в цей додаток';
$DOWNLOAD_YOUR_PHOTO_PREMISES = 												'завантажити своє фото приміщення';
$SELECT_A_ROOM_FROM_THE_GALLERY = 												'вибрати приміщення з галереї';
$SELECT_THE_VISIBLE_AREA_OF_THE_CEILING_BY_SIMPLY_CLICKING_ON_THE_CORNERS = 	'виділіть видиму область стелі просто клікаючи мишкою по кутах';
$ALL_CLEAR = 																	'все зрозуміло';
$ATTENTION = 																	'увага!';
$PRESS_THE_PENCIL_TO_START_THE_SELECTION_OF_THE_CEILING_AREA = 					'1. натисніть "олівець" для початку виділення області стелі.';
$TO_DELETE_THE_SELECTED_AREA_CLICK_ON_THE_TRASH = 								'2. для видалення виділеної області натисніть "кошик"';
$WHEN_THE_DOUBLE_CLICK_SELECTION_IS_COMPLETE = 									'3. після закінчення виділення подвійний клік миші.';
$APPLY = 																		'застосувати';
$TO_ACCOUNT_THE_COST_OF_SUCH_CEILING = 											'дізнатися вартість такого стелі';
$LEAVE_THE_APPLICATION_AND_RECEIVE_THE_CALCULATION = 							'залиште заявку і отримаєте розрахунок';
$ENTER_THE_CEILING_AREA = 														'введіть площа стелі';
$ENTER_YOUR_NAME = 																'введіть своє ім"я';
$ENTER_TELEPHONE_NUMBER = 														'Введіть номер телефону';
$GETTING_CALCULATING_IN_SMS = 													'отримати розрахунок в смс';
$PRIVACY_POLICY = 																'Політика конфіденційності';
$SAVE_THE_IMAGE = 																'зберегти зображення';
$CHANDELIER = 																	'люстра';
$CATALOG = 										'візуалізація натяжної стелі';
$GLOSSY = 																		'глянсовий';
$MATTED = 																		'матовий';
$SATINE = 																		'сатиновий';
$YOUR_CHOICE = 																	'ваш вибір';
$YOUR_CHOICE_PHOTO_PRINT = 														'ваш вибір: фотодрук №';
$YOUR_CHOICE_YOUR_PHOTO_PRINTING = 												'ваш вибір: своя фотодрук';
$NO_DOWNLOAD_ITEM = 															'немає елемента завантаження';
$THE_BROWSER_DOES_NOT_SUPPORT_UPLOADING_PHOTOS = 								'браузер не підтримує загруку фото';
$NO_FILE_SELECTED_FOR_UPLOAD = 													'файл не вибрано для завантаження';
$THE_PHOTO_MUST_BE_IN_JPG_PNG_OR_GIF_FORMAT = 									'фотографія повинна бути в форматі jpg, png або gif';
$THE_SIZE_OF_THE_PHOTO_SHOULD_NOT_EXCEED_5_MB = 								'розмір фотографії не повинен перевищувати 5 Мб';
$BACK = 																		'назад';
$DOWNLOAD_YOUR_OWN = 															'завантажити свою';
$PHOTOSHOP = 																	'фотодрук';
$HALL =																			'зал';
$BEDROOM =																		'спальня';
$CHILDREN =																		'дитяча';
$LIVING_ROOM =																	'вітальня';
$KITCHEN =																		'кухня';
$ENTRANCE_HALL =																'передпокій';
$BATHROOM =																		'ванна';

?> 