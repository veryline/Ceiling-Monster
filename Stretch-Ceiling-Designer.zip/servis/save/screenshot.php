<?php
		header('Content-Type: application/x-javascript; charset=utf8');
		
		if(isset($_POST["screenshot"]) && strlen($_POST["screenshot"]) > 0){
			$screenshot = str_replace("data:image/png;base64,", "", $_POST["screenshot"]);
			$base64 = base64_decode($screenshot);
			
			$name = "output/".time().".png";
			$png = fopen($name, "w");
			fwrite($png, $base64);
			fclose($png);
			
			$xxxxx = "xxxxxxx.png";
			$img = fopen($xxxxx, "w");
			fwrite($img, $base64);
			fclose($img);
	
			echo json_encode("Access!");
		} else {
			echo json_encode("Error");
		}	
?>