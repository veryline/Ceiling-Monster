<? require_once('../../config.php'); ?>

<link rel="stylesheet" href="<?=$baseurl;?>template/<?=$TEMPLATE;?>/css/style.css" >

<div id="container_one" class="color_container">
	<div class="left-color_container"><p><i class="fa fa-home"></i> Адрес вашего офиса</p></div>
	<div class="right-color_container"><p><i class="fa fa-phone-square"></i> Заказать обратный звонок</p></div>
	<div class="share">
		<div class="fab no" onclick="startmain()"><i class="share-left fa fa-camera"></i>Загрузить фото помещения</div>
		<div class="fab no" onclick="loadgallery()"><i class="share-right fa fa-picture-o"></i>Выбрать фото из галереи</div>
	</div>
	<div class="title-color_container">
		<p class="color_container-title"><span>Онлайн подбор цвета и фотопечати</span></p>
		<p class="color_container-title-sub"><span>натяжных потолков</span></p>
		<p class="color_container-subtitle"><span>Сфотографируйте свое помещение и подберите идеальный вариант по цвету</span></p>
	</div>
	<div class="button-color_container"><p><i class="fa fa-adjust"></i> Начать подбор</p></div>
	<section class="overlay-color_container"></section>
	<div class="box-color_container">
		<div class="color_container-logo"><a href="http://ip.veryline.ru/" target="_blank"></a></div>
		<div class="color_container-shutterstok"><img src="<?=$baseurl;?>template/<?=$TEMPLATE;?>/img/shutterstok.png" /></div>
	</div>
</div>



<section class="gallery_container_overlay">
	<div class="gallery_container" style="display: none;">
		
		<div id="jquery-accordion-menu4" class="jquery-accordion-menu green">
			<div class="submenu-gallery"><i class="fa fa-bars"></i>Выберите категорию</div>
			<ul class="submenu">
				<li><a class="active" href="#"><i class="fa fa-desktop"></i><?=$HALL;?><span class="jquery-accordion-menu-label">10 шт</span></a></li>
				<li><a href="#"><i class="fa fa-bed"></i><?=$BEDROOM;?><span class="jquery-accordion-menu-label">12 шт</span></a></li>
				<li><a href="#"><i class="fa fa-paw"></i><?=$CHILDREN;?><span class="jquery-accordion-menu-label">10 шт</span></a></li>
				<li><a href="#"><i class="fa fa-briefcase"></i><?=$LIVING_ROOM;?><span class="jquery-accordion-menu-label">10 шт</span></a></li>
				<li><a href="#"><i class="fa fa-birthday-cake"></i><?=$KITCHEN;?><span class="jquery-accordion-menu-label">7 шт</span></a></li>
				<li><a href="#"><i class="fa fa-paw"></i><?=$ENTRANCE_HALL;?><span class="jquery-accordion-menu-label">15 шт</span></a></li>
				<li><a href="#"><i class="fa fa-paw"></i><?=$BATHROOM;?><span class="jquery-accordion-menu-label">18 шт</span></a></li>
			</ul>
			<div class="submenu-gallery-return" onclick="backgallery()"><i class="fa fa-chevron-left"></i>Вернуться назад</div>
		</div>

		<div class="gallery_wrap_1">
			<aside>
				<section>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/5.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 44,143,45,144 ;316,206,317,207 ;638,150,639,151 ;644,161,645,162 ;740,147,741,148 ;755,1,756,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/6.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 57,146,58,147 ;346,202,347,203 ;756,65,757,66 ;763,2,764,3;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/7.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 57,64,58,65 ;510,118,511,119 ;724,1,725,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/8.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 48,107,49,108 ;369,208,370,209 ;737,143,738,144 ;747,0,748,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/9.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 46,29,47,30 ;162,70,163,71 ;163,100,164,101 ;372,163,373,164 ;387,161,388,162 ;457,180,458,181 ;767,135,768,136 ;767,0,768,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/10.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 44,98,45,99 ;397,213,398,214 ;751,179,752,180 ;757,1,758,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/11.jpg" width="135" height="85" alt="Потолок"  data-coord="103,2,104,3 ;103,2,104,3 ;193,105,194,106 ;671,109,672,110 ;772,40,773,41 ;772,0,773,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/12.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 70,79,71,80 ;442,144,443,145 ;729,1,730,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/13.jpg" width="135" height="85" alt="Потолок"  data-coord="138,1,139,2 ;138,1,139,2 ;379,152,380,153 ;686,113,687,114 ;707,0,708,1 ;707,0,708,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/15.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 58,105,59,106 ;427,149,428,150 ;748,31,749,32 ;752,1,753,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_zal/16.jpg" width="135" height="85" alt="Потолок"  data-coord="117,6,118,7 ;117,6,118,7 ;249,140,250,141 ;244,142,245,143 ;288,185,289,186 ;674,184,675,185 ;747,151,748,152 ;768,0,769,1;" /></a></div>
				</section>
				<section> 
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/1.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 69,103,70,104 ;111,129,112,130 ;562,131,563,132 ;702,1,703,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/2.jpg" width="135" height="85" alt="Потолок"  data-coord="66,4,67,5 ;66,4,67,5 ;252,79,253,80 ;251,94,252,95 ;231,106,232,107 ;385,158,386,159 ;653,88,654,89 ;607,1,608,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/3.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 76,6,77,7 ;211,155,212,156 ;601,156,602,157 ;623,135,624,136 ;624,121,625,122 ;618,118,619,119 ;616,117,617,118 ;608,105,609,106 ;598,99,599,100 ;673,0,674,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/4.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 61,65,62,66 ;364,138,365,139 ;736,16,737,17 ;738,0,739,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/5.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 56,109,57,110 ;301,177,302,178 ;735,86,736,87 ;747,0,748,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/6.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 54,95,55,96 ;417,166,418,167 ;759,77,760,78 ;759,0,760,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/7.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 46,81,47,82 ;224,113,225,114 ;739,62,740,63 ;743,1,744,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/9.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 52,66,53,67 ;230,129,231,130 ;336,163,337,164 ;419,186,420,187 ;481,201,482,202 ;772,88,773,89 ;763,2,764,3;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/10.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 64,16,65,17 ;172,98,173,99 ;480,93,481,94 ;489,0,490,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/12.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 56,73,57,74 ;261,85,262,86 ;262,99,263,100 ;678,122,679,123 ;760,109,761,110 ;757,0,758,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/13.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 50,3,51,4 ;460,138,461,139 ;669,58,670,59 ;596,0,597,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/14.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1;62,34,63,35 ;104,113,105,114 ;427,157,428,158 ;432,150,433,151 ;457,155,458,156 ;703,0,704,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_spalnaya/15.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1;66,89,67,90 ;74,91,75,92 ;121,91,122,92 ;121,85,122,86 ;277,84,278,85 ;280,91,281,92 ;528,88,529,89 ;528,85,529,86 ;672,85,673,86 ;748,21,749,22 ;735,0,736,1;" /></a></div>
				</section>
				<section>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/1.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 57,59,58,60 ;369,133,370,134 ;742,84,743,85 ;749,2,750,3;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/2.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 63,23,64,24 ;141,88,142,89 ;661,85,662,86 ;736,29,737,30 ;737,3,738,4;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/3.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 37,70,38,71 ;517,112,518,113 ;596,93,597,94 ;596,81,597,82 ;745,42,746,43 ;745,2,746,3 ;361,1,362,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/4.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 62,12,63,13 ;586,122,587,123 ;776,71,777,72 ;756,1,757,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/5.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 57,73,58,74 ;138,130,139,131 ;666,130,667,131 ;751,70,752,71 ;750,1,751,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/6.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 47,87,48,88 ;417,134,418,135 ;560,103,561,104 ;562,75,563,76 ;757,26,758,27 ;750,2,751,3;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/7.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 65,59,66,60;381,139,382,140;748,81,749,82;755,1,756,2" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/8.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 60,90,61,91 ;305,110,306,111 ;442,78,443,79 ;548,90,549,91 ;762,48,763,49 ;758,2,759,3;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/9.jpg" width="135" height="85" alt="Потолок"  data-coord="180,6,181,7 ;180,6,181,7 ;303,86,304,87 ;701,61,702,62 ;700,50,701,51 ;698,43,699,44 ;698,34,699,35 ;699,28,700,29 ;700,18,701,19 ;704,5,705,6 ;702,0,703,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_detskaya/10.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 64,18,65,19 ;512,98,513,99 ;759,51,760,52 ;766,0,767,1;" /></a></div>
				</section>
				<section> 
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/1.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 35,105,36,106 ;326,136,327,137 ;371,132,372,133 ;583,4,584,5 ;583,0,584,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/2.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 33,43,34,44 ;209,131,210,132 ;546,89,547,90 ;596,71,597,72 ;602,0,603,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/3.jpeg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1;54,23,55,24 ;399,149,400,150 ;739,85,740,86 ;743,1,744,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/4.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 36,122,37,123 ;230,179,231,180 ;260,171,261,172 ;369,207,370,208 ;369,221,370,222 ;388,227,389,228 ;432,222,433,223 ;453,227,454,228 ;622,208,623,209 ;618,198,619,199 ;693,190,694,191 ;722,1,723,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/5.jpg" width="135" height="85" alt="Потолок"  data-coord="238,5,239,6 ;238,5,239,6 ;180,138,181,139 ;552,218,553,219 ;743,180,744,181 ;741,0,742,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/6.jpg" width="135" height="85" alt="Потолок"  data-coord="180,3,181,4 ;180,3,181,4 ;165,66,166,67 ;426,175,427,176 ;746,39,747,40 ;744,0,745,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/7.jpg" width="135" height="85" alt="Потолок"  data-coord="69,34,70,35 ;69,34,70,35 ;96,24,97,25 ;238,43,239,44 ;238,58,239,59 ;587,112,588,113 ;621,108,622,109 ;642,113,643,114 ;734,105,735,106 ;744,1,745,2 ;65,0,66,1 ;64,0,65,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/8.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 63,91,64,92 ;103,114,104,115 ;102,132,103,133 ;235,203,236,204 ;251,200,252,201 ;271,209,272,210 ;273,210,274,211 ;274,224,275,225 ;586,219,587,220 ;742,52,743,53 ;743,1,744,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/9.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 57,39,58,40 ;409,94,410,95 ;598,1,599,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/10.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 60,128,61,129 ;178,183,179,184 ;564,176,565,177 ;703,4,704,5 ;705,1,706,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/11.jpg" width="135" height="85" alt="Потолок"  data-coord="60,60,61,61 ;60,60,61,61 ;418,187,419,188 ;557,166,558,167 ;564,168,565,169 ;742,141,743,142 ;754,1,755,2 ;56,0,57,1 ;56,0,57,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/12.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 134 ;56,133,57,134 ;147,140,148,141 ;182,144,183,145 ;234,151,235,152 ;266,156,267,157 ;313,164,314,165 ;433,190,434,191 ;453,188,454,189 ;462,190,463,191 ;577,182,578,183 ;577,170,578,171 ;743,164,744,165 ;751,1,752,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/13.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 41,190,42,191 ;278,216,279,217 ;309,211,310,212 ;330,216,331,217 ;745,159,746,160 ;750,0,751,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/15.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 53,75,54,76 ;198,113,199,114 ;237,86,238,87 ;606,169,607,170 ;757,139,758,140 ;758,1,759,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_gostinnaya/16.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 47,22,48,23 ;216,86,217,87 ;549,48,550,49 ;729,90,730,91 ;737,0,738,1;" /></a></div>
				</section>
				<section> 
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/1.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1;45,45,46,46 ;499,116,500,117 ;524,112,525,113 ;520,109,521,110 ;519,106,520,107 ;522,102,523,103 ;530,100,531,101 ;552,97,553,98 ;570,96,571,97 ;568,96,569,97 ;565,97,566,98 ;574,97,575,98 ;587,98,588,99 ;601,101,602,102 ;746,75,747,76 ;750,0,751,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/2.jpg" width="135" height="85" alt="Потолок"  data-coord="17,16,18,17 ;17,16,18,17 ;109,13,110,14 ;266,69,267,70 ;751,41,752,42 ;749,0,750,1 ;33,0,34,1 ;33,0,34,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/3.jpg" width="135" height="85" alt="Потолок"  data-coord="52,61,53,62 ;52,61,53,62 ;74,61,75,62 ;208,77,209,78 ;217,80,218,81 ;220,85,221,86 ;220,90,221,91 ;373,108,374,109 ;431,107,432,108 ;545,90,546,91 ;553,86,554,87 ;564,82,565,83 ;588,77,589,78 ;615,73,616,74 ;661,68,662,69 ;743,55,744,56 ;748,1,749,2 ;27,0,28,1 ;27,0,28,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/4.jpg" width="135" height="85" alt="Потолок"  data-coord="90,3,91,4 ;90,3,91,4 ;127,57,128,58 ;669,63,670,64 ;719,0,720,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/5.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 34,30,35,31 ;75,33,76,34 ;375,63,376,64 ;516,80,517,81 ;579,79,580,80 ;632,77,633,78 ;680,71,681,72 ;711,65,712,66 ;735,64,736,65 ;740,1,741,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/6.jpg" width="135" height="85" alt="Потолок"  data-coord="115,1,116,1 ;115,1,116,1 ;115,6,116,7 ;205,66,206,67 ;760,52,761,53 ;755,1,756,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/7.jpg" width="135" height="85" alt="Потолок"  data-coord="52,1,53,1 ;52,1,53,1 ;52,32,53,33 ;116,84,117,85 ;224,82,225,83 ;224,69,225,70 ;710,68,711,69 ;730,56,731,57 ;743,3,744,4;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/8.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 43,15,44,16 ;125,66,126,67 ;419,65,420,66 ;419,70,420,71 ;676,67,677,68 ;743,30,744,31 ;740,1,741,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/9.jpg" width="135" height="85" alt="Потолок"  data-coord="1,1,1,1; 1,1,1,1; 49,34,50,35 ;129,82,130,83 ;622,83,623,84 ;739,4,740,5;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_kuhnya/10.jpg" width="135" height="85" alt="Потолок"  data-coord="44,1,45,2 ;44,1,45,2 ;340,127,341,128 ;396,121,397,122 ;443,144,444,145 ;749,116,750,117 ;747,1,748,2;" /></a></div>
				</section>
				<section>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_prihojaya/1.jpg" width="135" height="85" alt="Потолок"  data-coord="51,1,52,1 ;51,1,52,1 ;385,385,386,386 ;587,380,588,381 ;641,206,642,207 ;730,200,731,201 ;743,0,744,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_prihojaya/2.jpg" width="135" height="85" alt="Потолок"  data-coord="3,1,4,1 ;3,1,4,1 ;3,38,4,39 ;268,101,269,102 ;743,28,744,29 ;744,1,745,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_prihojaya/3.jpg" width="135" height="85" alt="Потолок"  data-coord="217,1,218,2 ;217,1,218,2 ;252,151,253,152 ;549,171,550,172 ;681,91,682,92 ;681,0,682,1 ;681,0,682,1 ;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_prihojaya/4.jpg" width="135" height="85" alt="Потолок"  data-coord="58,1,59,1 ;8,1,59,1 ;58,205,59,206 ;151,272,152,273 ;526,265,527,266 ;524,245,525,246 ;520,243,521,244 ;518,238,519,239 ;514,238,515,239 ;510,237,511,238 ;509,234,510,235 ;535,209,536,210 ;531,205,532,206 ;527,205,528,206 ;524,204,525,205 ;520,202,521,203 ;708,1,709,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_prihojaya/5.jpg" width="135" height="85" alt="Потолок"  data-coord="48,1,49,1 ;48,1,49,1 ;48,87,49,88 ;95,263,96,264 ;94,301,95,302 ;367,340,368,341 ;759,117,760,118 ;767,2,768,3;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_prihojaya/6.jpg" width="135" height="85" alt="Потолок"  data-coord="76,0,77,1 ;76,0,77,1 ;184,397,185,398 ;492,403,493,404 ;746,182,747,183 ;750,1,751,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_prihojaya/7.jpg" width="135" height="85" alt="Потолок"  data-coord="86,2,87,3 ;86,2,87,3 ;264,337,265,338 ;508,337,509,338 ;763,81,764,82 ;757,1,758,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_prihojaya/9.jpg" width="135" height="85" alt="Потолок"  data-coord="19,1,20,1 ;19,1,20,1 ;19,240,20,241 ;347,324,348,325 ;754,188,755,189 ;750,1,751,2;" /></a></div>
				</section>

				<section>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/1.jpg" width="135" height="85" alt="Потолок"  data-coord="37,5,38,6 ;37,5,38,6 ;250,257,251,258 ;62,33,63,34 ;62,33,63,34 ;249,254,250,255 ;249,254,250,255 ;526,256,527,257 ;526,256,527,257 ;573,185,574,186 ;573,185,574,186 ;620,185,621,186 ;620,185,621,186 ;749,35,750,36 ;749,35,750,36 ;741,4,742,5 ;741,4,742,5 ;69,3,70,4 ;69,3,70,4 ;69,3,70,4 ;69,3,70,4;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/2.jpg" width="135" height="85" alt="Потолок"  data-coord="60,59,61,60 ;60,59,61,60 ;300,213,301,214 ;751,112,752,113 ;749,2,750,3 ;57,3,58,4 ;57,3,58,4;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/3.jpg" width="135" height="85" alt="Потолок"  data-coord="243,3,244,4 ;243,3,244,4 ;331,251,332,252 ;588,243,589,244 ;710,3,711,4 ;710,3,711,4;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/4.jpg" width="135" height="85" alt="Потолок"  data-coord="60,77,61,78 ;60,77,61,78 ;235,190,236,191 ;530,164,531,165 ;528,158,529,159 ;528,153,529,154 ;531,147,532,148 ;539,140,540,141 ;551,133,552,134 ;562,129,563,130 ;597,5,598,6 ;62,2,63,3 ;62,2,63,3;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/6.jpg" width="135" height="85" alt="Потолок"  data-coord="48,291,49,292 ;48,291,49,292 ;97,391,98,392 ;459,411,460,412 ;479,390,480,391 ;543,394,544,395 ;750,208,751,209 ;744,6,745,7 ;57,1,58,1 ;57,1,58,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/7.jpg" width="135" height="85" alt="Потолок"  data-coord="49,348,50,349 ;49,348,50,349 ;512,376,513,377 ;526,367,527,368 ;537,359,538,360 ;758,174,759,175 ;740,4,741,5 ;53,2,54,3 ;48,615,49,616 ;68,615,69,616 ;739,616,740,617 ;730,207,731,208 ;541,366,542,367 ;543,375,544,376 ;553,368,554,369 ;557,378,558,379 ;730,388,731,389 ;746,617,747,618 ;49,616,50,617 ;46,349,47,350 ;46,349,47,350;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/9.jpg" width="135" height="85" alt="Потолок"  data-coord="75,1,76,1 ;75,1,76,1 ;143,68,144,69 ;680,70,681,71 ;733,25,734,26 ;737,1,738,1 ;737,1,738,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/10.jpg" width="135" height="85" alt="Потолок"  data-coord="126,4,127,5 ;126,4,127,5 ;250,235,251,236 ;689,225,690,226 ;737,136,738,137 ;739,2,740,3 ;130,1,131,2 ;130,1,131,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/11.jpg" width="135" height="85" alt="Потолок"  data-coord="53,53,54,54 ;53,53,54,54 ;314,167,315,168 ;622,118,623,119 ;672,5,673,6 ;671,2,672,3 ;49,0,50,1 ;49,0,50,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/12.jpg" width="135" height="85" alt="Потолок"  data-coord="69,1,70,1 ;69,1,70,1 ;305,136,306,137 ;637,98,638,99 ;639,5,640,6 ;639,2,640,3 ;639,1,640,2;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/13.jpg" width="135" height="85" alt="Потолок"  data-coord="51,156,52,157 ;51,156,52,157 ;361,263,362,264 ;748,172,749,173 ;756,2,757,3 ;52,0,53,1 ;52,0,53,1;" /></a></div>
					<div><a href="#"><img src="<?=$baseurl;?>interfaces/gallery_pom/gallery_vannaya/14.jpg" width="135" height="85" alt="Потолок"  data-coord="186,0,187,1 ;186,0,187,1 ;255,102,256,103 ;587,104,588,105 ;688,3,689,4 ;688,0,689,1 ;688,0,689,1;" /></a></div>
				</section>

			</aside>
		</div>
	</div>
</section>

<script language="JavaScript" type="text/javascript" >
$(".button-color_container p").on('click', function(e) {
  $(".fab").removeClass("no");
  if(e.target != this) return;
  $('.button-color_container p, .fab').toggleClass("active");
});

function loadgallery(){
	$(".color_container").fadeOut();
	$(".gallery_container").fadeIn();
}

function backgallery(){
	$(".gallery_container").fadeOut();
	$(".color_container").fadeIn();
}


$(window).ready(function() {
		$('.color_container-logo a').load('<?=$baseurl;?>template/template_2/css/standart/logo/logo.svg');
		$("#jquery-accordion-menu4").jqueryAccordionMenu();
		
		$(".gallery_container section").hide();
		$(".gallery_container section").first().show();
		
		$('.gallery_container li a').on('click', function(){
		  var  i = $(this).parent().index();
		   $(".gallery_container section").hide();
		   $(".gallery_container section:eq("+i+")").show();
		   
		   $(".gallery_container li a").removeClass("active");
		   $(".gallery_container li a:eq("+i+")").addClass("active");
		});

		$(".gallery_container section div a").on('click', function(){
			startgallery(
				$(this).find("img").attr("src"), 
				$(this).find("img").data("coord")
			);
		});
});
</script>